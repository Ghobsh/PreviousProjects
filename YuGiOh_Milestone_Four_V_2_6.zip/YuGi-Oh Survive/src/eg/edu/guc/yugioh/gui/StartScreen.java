package eg.edu.guc.yugioh.gui;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import eg.edu.guc.yugioh.board.player.Player;
import eg.edu.guc.yugioh.exceptions.UnexpectedFormatException;

public class StartScreen extends JFrame{
	
	JTextArea Player1 = new JTextArea("Yugi");
	JTextArea Player2 = new JTextArea("Kaiba");
	JButton start = new JButton("Duel!");
	
	public static Player P1;
	public static Player P2;
	
	public StartScreen(){
		super();
		setSize(new Dimension(400,300));
		JPanel left = new JPanel();
		left.setLayout(new GridLayout(2,1));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
		Player1.setPreferredSize(new Dimension(150, 30));
		Player2.setPreferredSize(new Dimension(150, 30));
		start.setSize(100, 40);
		
		JPanel left1 = new JPanel();
		left1.setLayout(new FlowLayout());
		
		JPanel left2 = new JPanel();
		left2.setLayout(new FlowLayout());
		
		left1.add(Player1);
		left2.add(Player2);
		
		left.add(left1);
		left.add(left2);
		
		add(left);
		add(start);
		
		this.setLayout(new FlowLayout());
		
		start.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				setVisible(false);
				
				try {
					P1 = new Player(Player1.getText());
					P2 = new Player(Player2.getText());
					new Interface();
					TempoPanel.refresh();
				} catch (Exception e1) {
//					System.out.println(e1.getMessage()+"hena");
					e1.printStackTrace();
				}
				
			}
		});
		
	}
	
	public static void main(String[] args) {
		new StartScreen();
	}

}
