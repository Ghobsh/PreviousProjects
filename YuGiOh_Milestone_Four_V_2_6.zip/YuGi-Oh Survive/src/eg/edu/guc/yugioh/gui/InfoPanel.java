package eg.edu.guc.yugioh.gui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.MonsterCard;

public class InfoPanel extends JPanel{

	static GUIBoard bd;

	JPanel Pic = new JPanel();
	static JLabel pic = new JLabel();
	ImageIcon picIcon = new ImageIcon("Card Back.png");

	static JLabel Name= new JLabel("Name: ");
	static JLabel Desc= new JLabel("Desription: ");
	static JLabel Attk= new JLabel("Attack: ");
	static JLabel Def= new JLabel("Defense: ");
	static JLabel Lvl= new JLabel("Level: ");
	Card monster;

	public InfoPanel() throws IOException {
		super();
		monster=null;
		setPreferredSize(new Dimension(300, bd.getHeight()));

		Pic.setPreferredSize(new Dimension(250,400));

		setVisible(true);

		pic.setIcon(picIcon);
		Pic.add(pic);

		setLayout(new GridLayout(2,1));
		add(Pic);

		JPanel res = new JPanel();
		res.setPreferredSize(new Dimension(this.getWidth(), 500));
		res.setLayout(new GridLayout(5,1));
		res.add(Name);
		res.add(Attk);
		res.add(Def);
		res.add(Lvl);
		JScrollPane res2 = new JScrollPane(Desc);
		//		res2.add(Desc);
		res.add(res2);

		add(res);

		pic.setIcon(new ImageIcon(picIcon.getImage().getScaledInstance(200, 250,  java.awt.Image.SCALE_SMOOTH)));

	}

	public static void change(Object source) {
		HoverableLabel x = (HoverableLabel)source;
		Card c = x.getX2();

		if(ActiveField.getHand().contains(x) ||ActiveField.getMonster().contains(x) ||ActiveField.getSpell().contains(x) || (OpponentField.getHand().contains(x)&& !x.getX2().isHidden()) || (OpponentField.getMonster().contains(x)&& !x.getX2().isHidden())|| (OpponentField.getSpell().contains(x)&& !x.getX2().isHidden())){
			pic.setIcon(new ImageIcon(new ImageIcon(c.getPic()).getImage().getScaledInstance(200, 250,  java.awt.Image.SCALE_SMOOTH)));

			Name.setText("Name: " + c.getName());
			Desc.setText("Desc: " + c.getDescription());

			if(c instanceof MonsterCard){
				Attk.setText("Attack: " + ((MonsterCard)c).getAttackPoints());
				Def.setText("Defense: " + ((MonsterCard)c).getDefensePoints());
				Lvl.setText("Level: " + ((MonsterCard)c).getLevel());
			} else {
				Attk.setText("Attack: N/A" );
				Def.setText("Defense: N/A" );
				Lvl.setText("Level: N/A" );
			}
		}
	}

	public static void changeGrave(Object source) {
		GraveLabel x = (GraveLabel)source;

		ArrayList<Card> r = (source == ActiveField.activeGrave)? Card.getBoard().getActivePlayer().getField().getGraveyard(): Card.getBoard().getOpponentPlayer().getField().getGraveyard();

		if(r.size()!=0){
			if(r.get(r.size()-1) != null)
				pic.setIcon(new ImageIcon(new ImageIcon(r.get(r.size()-1).getPic()).getImage().getScaledInstance(200, 250,  java.awt.Image.SCALE_SMOOTH)));

			Name.setText("Name: " + ((r.get(r.size()-1)!=null)?r.get(r.size()-1).getName():""));
			Desc.setText("This graveyard Contains: " + Foldr(r));

			if(r.get(r.size()-1)!=null)
				if(r.get(r.size()-1) instanceof MonsterCard){
					Attk.setText("Attack: "  + ((MonsterCard)r.get(r.size()-1)).getAttackPoints());
					Def.setText("Defense: "  + ((MonsterCard)r.get(r.size()-1)).getDefensePoints());
					Lvl.setText("Level: " + ((MonsterCard)r.get(r.size()-1)).getLevel());
				} else {
					Attk.setText("Attack: N/A" );
					Def.setText("Defense: N/A" );
					Lvl.setText("Level: N/A" );

				}
		}

	}

	public static String Foldr(ArrayList<Card> r){
		String s = "";
		for (int i = 0; i <r.size()-1; i++) {
			s+=r.get(i).getName()+ ", ";
		}
		s+=r.get(r.size()-1).getName();
		return s;
	}



}
