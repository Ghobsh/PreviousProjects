package eg.edu.guc.yugioh.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import eg.edu.guc.yugioh.board.player.Player;

public class ActiveField extends JPanel{

	private Player player;

	private static ArrayList<HLabel> Hand = new ArrayList<HLabel>();
	private static ArrayList<SLabel> Spell = new ArrayList<SLabel>();
	private static ArrayList<MLabel> Monster = new ArrayList<MLabel>();

	private static JPanel HandArea = new JPanel();
	private static JPanel MonsterArea = new JPanel();
	private static JPanel SpellArea = new JPanel();

	public static void setHandArea(JPanel handArea) {
		HandArea = handArea;
	}


	static GraveLabel activeGrave = new GraveLabel();
	static DeckLabel activeDeck = new DeckLabel();

	public void clrall(){
		Hand = new ArrayList<HLabel>();
		Spell = new ArrayList<SLabel>();
		Monster = new ArrayList<MLabel>();

		HandArea = new JPanel();
		MonsterArea = new JPanel();
		SpellArea = new JPanel();
	}	
	public ActiveField(){

		clrall();
		setLayout(new GridLayout(3,1));
		setVisible(true);

		JPanel MonsterPane = new JPanel();
		JPanel SpellPane = new JPanel();

		MonsterPane.setLayout(new BorderLayout());
		SpellPane.setLayout(new BorderLayout());

		//		getHandArea().setBackground(Color.BLACK);
		//		SpellArea.setBackground(Color.YELLOW);
		//		MonsterArea.setBackground(Color.BLUE);

		MonsterPane.add(MonsterArea);
		SpellPane.add(SpellArea);
		
		MonsterArea.setBackground(Color.DARK_GRAY);
		SpellArea.setBackground(Color.LIGHT_GRAY);

		MonsterPane.add(activeGrave,BorderLayout.WEST);
		SpellPane.add(activeDeck,BorderLayout.WEST);

		add(MonsterPane);
		add(SpellPane);

		//		add(getHandArea());

		JScrollPane x = new JScrollPane(HandArea);
		add(x);
	}




	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public static GraveLabel getActiveGrave() {
		return activeGrave;
	}




	public static void setActiveGrave(GraveLabel activeGrave2){
		activeGrave = activeGrave2;
	}




	public static DeckLabel getActiveDeck() {
		return activeDeck;
	}




	public static void setActiveDeck(DeckLabel activeDeck2) {
		activeDeck = activeDeck2;
	}




	public static ArrayList<HLabel> getHand() {
		return Hand;
	}

	public static void setHand(ArrayList<HLabel> hand) {
		Hand = hand;
	}

	public static ArrayList<SLabel> getSpell() {
		return Spell;
	}

	public static void setSpell(ArrayList<SLabel> spell) {
		Spell = spell;
	}

	public static ArrayList<MLabel> getMonster() {
		return Monster;
	}

	public static void setMonster(ArrayList<MLabel> monster) {
		Monster = monster;
	}

	public static JPanel getHandArea() {
		return HandArea;
	}

	public static JPanel getMonsterArea() {
		return MonsterArea;
	}

	public static void setMonsterArea(JPanel monsterArea) {
		MonsterArea = monsterArea;
	}

	public static JPanel getSpellArea() {
		return SpellArea;
	}

	public static void setSpellArea(JPanel spellArea) {
		SpellArea = spellArea;
	}

}
