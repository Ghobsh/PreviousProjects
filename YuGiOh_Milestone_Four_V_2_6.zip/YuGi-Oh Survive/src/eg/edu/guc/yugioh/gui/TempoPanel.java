package eg.edu.guc.yugioh.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.listeners.EndPhaseListener;
import eg.edu.guc.yugioh.listeners.EndTurnListener;

public class TempoPanel extends JPanel{


	public static JLabel Player2Name = new JLabel("Player: " );
	public static JLabel Player1Name = new JLabel("Player: " );
	public static JLabel Player2LP = new JLabel("LP: " );
	public static JLabel Player1LP = new JLabel("LP: ");

	public static JButton EndPhase = new JButton("Phase: Main1");
	public static JButton EndTurn = new JButton("First Turn");

	static GUIBoard gb;

	public TempoPanel(){
		super();

		JPanel UpperPart = new JPanel();
		JPanel MiddlePart = new JPanel();
		JPanel LowerPart = new JPanel();

		setSize(2000, gb.getHeight());

		setLayout(new GridLayout(3,1));

		add(UpperPart);
		add(MiddlePart);
		add(LowerPart);

		UpperPart.setLayout(new GridLayout(2,1));
		UpperPart.add(Player1Name);
		UpperPart.add(Player1LP);

		LowerPart.setLayout(new GridLayout(2,1));
		LowerPart.add(Player2LP);
		LowerPart.add(Player2Name);

		MiddlePart.setLayout(new GridLayout(2,1));
		JPanel Mid1 = new JPanel(new FlowLayout());
		Mid1.add(EndPhase);
		JPanel Mid2 = new JPanel(new FlowLayout());
		Mid2.add(EndTurn);
		MiddlePart.add(Mid1);
		MiddlePart.add(Mid2);

		EndPhase.setPreferredSize(new Dimension(150, 80));
		EndTurn.setPreferredSize(new Dimension(150, 80));

		EndPhase.addActionListener(new EndPhaseListener());
		EndTurn.addActionListener(new EndTurnListener());




	}

	public static void refreshStart() {
		Player2Name.setText( Card.getBoard().getActivePlayer().getName());

		Player1Name.setText( Card.getBoard().getOpponentPlayer().getName());

		EndTurn.setText(Card.getBoard().getActivePlayer().getName() + "\'s turn");



		//		refresh();
	}

	public static void refresh(){
		EndTurn.setText(Card.getBoard().getActivePlayer().getName() + "\'s turn");

		if(Card.getBoard().getActivePlayer() == Interface.ini1){
			Player1LP.setText("LP: " + Card.getBoard().getOpponentPlayer().getLifePoints());
			Player2LP.setText("LP: " + Card.getBoard().getActivePlayer().getLifePoints());
		} else {
			Player1LP.setText("LP: " + Card.getBoard().getActivePlayer().getLifePoints());
			Player2LP.setText("LP: " + Card.getBoard().getOpponentPlayer().getLifePoints());

		}

		gb.repaint();
		gb.revalidate();

		gb.refresh();
	}
}
