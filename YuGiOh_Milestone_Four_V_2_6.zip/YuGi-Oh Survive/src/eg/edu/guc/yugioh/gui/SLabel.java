package eg.edu.guc.yugioh.gui;

import java.awt.Dimension;

import javax.swing.JLabel;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.listeners.HoverListener;

public class SLabel extends HoverableLabel{
	
	
	public SLabel (Card c){
		super(c);
		setPreferredSize(new Dimension(100,100));
//		addMouseListener(Interface.Control);
	}
	

}
