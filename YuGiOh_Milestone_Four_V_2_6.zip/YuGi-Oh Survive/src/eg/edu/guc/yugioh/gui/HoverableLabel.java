package eg.edu.guc.yugioh.gui;

import javax.swing.JLabel;

import eg.edu.guc.yugioh.cards.Card;

public class HoverableLabel extends JLabel{

	Card x;

	public Card getX2(){
		return x;
	}

	public HoverableLabel(Card c){
		super();
		x=c;
		this.addMouseListener(Interface.Control);
	}
	
}
