package eg.edu.guc.yugioh.gui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPanel;

import eg.edu.guc.yugioh.board.Board;
import eg.edu.guc.yugioh.board.player.Field;
import eg.edu.guc.yugioh.board.player.Player;
import eg.edu.guc.yugioh.exceptions.UnexpectedFormatException;

public class GUIBoard extends JPanel{

	OpponentField opp = new OpponentField();
	ActiveField act = new ActiveField();
	
	public GUIBoard(){
		super();
		 opp = new OpponentField();
		 act = new ActiveField();
		setVisible(true);
		setSize(850, 700);
//		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		setLayout(new BorderLayout());
		
		InfoPanel.bd = this;
		TempoPanel.gb = this;
		
		add(opp, BorderLayout.NORTH);
		add(act, BorderLayout.SOUTH);
		
		Field.setInter(this);
		
	}
	
	
//	public static void main(String[] args) throws NumberFormatException, CloneNotSupportedException, IOException, UnexpectedFormatException {
//		new GUIBoard();
//		Player p1 = new Player("yugi");
//		Player p2 = new Player("kaiba");
//		Board b = new Board();
//		b.startGame(p1, p2);
//		
//	}


	public static void ChangeRefs(){
		ArrayList handtmp = ActiveField.getHand();
		JPanel handareatmp = ActiveField.getHandArea();
		ArrayList monstertmp = ActiveField.getMonster();
		JPanel monsterareatmp = ActiveField.getMonsterArea();
		ArrayList spelltmp = ActiveField.getSpell();
		JPanel spellareatmp = ActiveField.getSpellArea();
		
		
		ActiveField.setHand(OpponentField.getHand());
		ActiveField.setHandArea(OpponentField.getHandArea());
		ActiveField.setMonster(OpponentField.getMonster());
		ActiveField.setMonsterArea(OpponentField.getMonsterArea());
		ActiveField.setSpell(OpponentField.getSpell());
		ActiveField.setSpellArea(OpponentField.getSpellArea());
	
		OpponentField.setHand(handtmp);
		OpponentField.setHandArea(handareatmp);
		OpponentField.setMonster(monstertmp);
		OpponentField.setMonsterArea(monsterareatmp);
		OpponentField.setSpell(spelltmp);
		OpponentField.setSpellArea(spellareatmp);
		
		GraveLabel acg = ActiveField.getActiveGrave();
		DeckLabel acd = ActiveField.getActiveDeck();
		
		ActiveField.setActiveGrave(OpponentField.getActiveGrave());
		ActiveField.setActiveDeck(OpponentField.getActiveDeck());
		
		OpponentField.setActiveGrave(acg);
		OpponentField.setActiveDeck(acd);
		
	}


	public static void hideHand() {
		for (int i = 0; i < OpponentField.getHand().size(); i++) {
			ImageIcon imageIcon = new ImageIcon("Card Back.png");// load the image to a imageIcon
			Image image = imageIcon.getImage(); // transform it 
			Image newimg = image.getScaledInstance(80, 100,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
			imageIcon = new ImageIcon(newimg);  // transform it back
			OpponentField.getHand().get(i).setIcon(imageIcon);
		}
		
		for (int i = 0; i < ActiveField.getHand().size(); i++) {
			ImageIcon imageIcon = new ImageIcon(ActiveField.getHand().get(i).getX2().getPic());// load the image to a imageIcon
			Image image = imageIcon.getImage(); // transform it 
			Image newimg = image.getScaledInstance(80, 100,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
			imageIcon = new ImageIcon(newimg);  // transform it back
			ActiveField.getHand().get(i).setIcon(imageIcon);
		}
	}


	public void refresh() {
		Interface.t.repaint();
		Interface.t.revalidate();
	}
	
}
