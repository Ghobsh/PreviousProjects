package eg.edu.guc.yugioh.gui;

import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileNotFoundException;

import javax.swing.JLabel;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.MonsterCard;
import eg.edu.guc.yugioh.cards.spells.SpellCard;
import eg.edu.guc.yugioh.listeners.HandListener;
import eg.edu.guc.yugioh.listeners.HoverListener;

public class HLabel extends HoverableLabel{
	
	public HLabel (Card c){
		super(c);
		setPreferredSize(new Dimension(100,100));
//		this.addMouseListener(Interface.Control);
//		addMouseListener(new HoverListener(this));
	}

	

}
