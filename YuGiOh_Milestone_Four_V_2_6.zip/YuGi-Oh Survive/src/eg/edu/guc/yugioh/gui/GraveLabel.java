package eg.edu.guc.yugioh.gui;

import java.awt.Dimension;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import eg.edu.guc.yugioh.listeners.GraveHover;

public class GraveLabel extends JLabel{

	
	public GraveLabel(){
		super();
		setPreferredSize(new Dimension(100,100));
		ImageIcon imageIcon = new ImageIcon(("Card Back.png"));// load the image to a imageIcon
		Image image = imageIcon.getImage(); // transform it 
		Image newimg = image.getScaledInstance(80, 100,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
		imageIcon = new ImageIcon(newimg);  // transform it back
		this.setIcon(imageIcon);
		this.addMouseListener(new GraveHover());
	}
	
}
