package eg.edu.guc.yugioh.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.IOException;

import javax.swing.JFrame;

import eg.edu.guc.yugioh.board.Board;
import eg.edu.guc.yugioh.board.player.Player;
import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.exceptions.UnexpectedFormatException;
import eg.edu.guc.yugioh.listeners.HandListener;


public class Interface extends JFrame{


	public static HandListener Control = new HandListener();

	Player p1 = StartScreen.P1;
	Player p2 = StartScreen.P2;

	public static Player ini1; 
	public static Player ini2;

	public static TempoPanel t;

	public Interface() throws IOException, NumberFormatException, CloneNotSupportedException, UnexpectedFormatException{
		super();
		p1 = StartScreen.P1;
		p2 = StartScreen.P2;

		setSize(1000,700);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);

		setBackground(Color.DARK_GRAY);


		setLayout(new BorderLayout());
		GUIBoard x = new GUIBoard();
		Board b = new Board();
		b.startGame(p1, p2);
		t=new TempoPanel();
		add(t, BorderLayout.WEST);
		add(x);
		add(new InfoPanel(), BorderLayout.EAST);

		ini1=Card.getBoard().getActivePlayer();
		ini2 = Card.getBoard().getOpponentPlayer();

		TempoPanel.refreshStart();
		//		add(new GUIBoard(), BorderLayout.CENTER);
		//		add(new InfoPanel(), BorderLayout.EAST);


	}

	public static void main(String[] args) throws NumberFormatException, IOException, CloneNotSupportedException, UnexpectedFormatException {
		new Interface();
	}
}
