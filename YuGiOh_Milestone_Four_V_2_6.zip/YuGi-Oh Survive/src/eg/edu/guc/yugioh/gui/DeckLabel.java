package eg.edu.guc.yugioh.gui;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import eg.edu.guc.yugioh.cards.Card;

public class DeckLabel extends JLabel{

	
	public DeckLabel(){
		super();
		setPreferredSize(new Dimension(100,100));
		ImageIcon imageIcon = new ImageIcon(("Card Back.png"));// load the image to a imageIcon
		Image image = imageIcon.getImage(); // transform it 
		Image newimg = image.getScaledInstance(80, 100,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
		imageIcon = new ImageIcon(newimg);  // transform it back
		this.setIcon(imageIcon);
		this.addMouseListener((new MouseListener() {
			
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			public void mouseClicked(MouseEvent arg0) {
				JOptionPane.showMessageDialog(null, "Cards left: " + ((arg0.getSource()==ActiveField.activeDeck)? Card.getBoard().getActivePlayer().getField().getDeck().getDeck().size():Card.getBoard().getOpponentPlayer().getField().getDeck().getDeck().size()));
			}
		}));
		
	}
	
}
