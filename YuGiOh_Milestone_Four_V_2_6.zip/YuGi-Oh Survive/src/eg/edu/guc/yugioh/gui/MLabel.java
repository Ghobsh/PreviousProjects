package eg.edu.guc.yugioh.gui;

import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JLabel;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.listeners.HandListener;
import eg.edu.guc.yugioh.listeners.HoverListener;

public class MLabel extends HoverableLabel {
	
	
	public MLabel (Card c){
		super(c);
		setPreferredSize(new Dimension(100,100));
//		addMouseListener(Interface.Control);
	}




}
