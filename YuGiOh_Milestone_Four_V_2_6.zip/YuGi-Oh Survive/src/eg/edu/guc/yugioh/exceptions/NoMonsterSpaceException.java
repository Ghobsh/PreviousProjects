package eg.edu.guc.yugioh.exceptions;

public class NoMonsterSpaceException extends NoSpaceException{

	public NoMonsterSpaceException(){
		super("No space left in the monsters area");
	}
	
//	public String getLocalizedMessage(){
//		return "Monster area is full, unable to set spell card to field.";
//	}
//	

}
