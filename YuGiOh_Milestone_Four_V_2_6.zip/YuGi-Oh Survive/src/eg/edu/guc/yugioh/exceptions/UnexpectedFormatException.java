package eg.edu.guc.yugioh.exceptions;

public class UnexpectedFormatException extends Exception {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String sourceFile="";
	private int sourceLine=0;

	public UnexpectedFormatException(String sourceFile, int sourceLine){
		super("Khara");
		this.sourceFile = sourceFile;
		this.sourceLine = sourceLine;

	}

	

	public void setSourceFile(String sourceFile) {
		this.sourceFile = sourceFile;
	}



	public void setSourceLine(int sourceLine) {
		this.sourceLine = sourceLine;
	}



	public String getSourceFile() {
		return sourceFile;
	}

	public int getSourceLine() {
		return sourceLine;
	}



}
