package eg.edu.guc.yugioh.exceptions;

public class UnknownCardTypeException extends UnexpectedFormatException {

	private String unknownType="";
	
	public String getUnknownType() {
		return unknownType;
	}


	public UnknownCardTypeException(String sourceFile, int Counter, String unknownType) {
		super(sourceFile, Counter);
		this.unknownType=unknownType;
	}


//	public String getLocalizedMessage(){
//		return "UnknownCardTypeException in file: "+getSourceFile()+ ", data line contains an unknown type in line: "+ getSourceLine();
//	}

}
