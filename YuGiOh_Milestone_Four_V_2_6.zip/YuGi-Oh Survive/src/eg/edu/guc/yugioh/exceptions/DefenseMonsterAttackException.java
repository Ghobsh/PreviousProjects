package eg.edu.guc.yugioh.exceptions;

public class DefenseMonsterAttackException extends RuntimeException {

		
	public DefenseMonsterAttackException(){
		super("Defending monsters can't attack");
		
	}
	
//	public String getLocalizedMessage(){
//		return " is in defense mode, please switch it to attack mode in order for it to attack.";
//	}
}
