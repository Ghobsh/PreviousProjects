package eg.edu.guc.yugioh.exceptions;

public class NoSpellSpaceException extends NoSpaceException{

	public NoSpellSpaceException(){
		super("No space left in spells area");
	}
	
//	public String getLocalizedMessage(){
//		return "Spell area is full, unable to set spell card to field.";
//	}

}
