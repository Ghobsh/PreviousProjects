package eg.edu.guc.yugioh.exceptions;

public class MultipleMonsterAdditionException extends RuntimeException{

	
	public MultipleMonsterAdditionException(){
		super("You summoned a monster successfully, you can't summon again this turn");
		
	}
	
	public String getLocalizedMessage(){
		return "You have already regular-summoned a monster this turn, please wait for the next turn to summon again";
	}

}
