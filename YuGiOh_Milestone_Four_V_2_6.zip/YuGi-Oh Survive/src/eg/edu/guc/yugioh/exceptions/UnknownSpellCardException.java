package eg.edu.guc.yugioh.exceptions;

public class UnknownSpellCardException extends UnexpectedFormatException{

	
	private String unknownSpell="";
	
	public String getUnknownSpell() {
		return unknownSpell;
	}



	public void setUnknownSpell(String unknownSpell) {
		this.unknownSpell = unknownSpell;
	}



	public UnknownSpellCardException(String File, int Line, String unknownSpell) {
		super(File, Line);
		this.unknownSpell=unknownSpell;
	}

	

//	public String getLocalizedMessage(){
//		return "UnknownSpellCardException, SpellCard database contains an unknown SpellCard in line: " + getLine();
//	}

}
