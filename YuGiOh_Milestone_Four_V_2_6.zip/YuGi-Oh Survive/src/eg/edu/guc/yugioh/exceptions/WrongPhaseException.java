package eg.edu.guc.yugioh.exceptions;

public class WrongPhaseException extends RuntimeException{

	public WrongPhaseException(){
		super("Wrong Phase, you can't do that now");
	}
	
	public String getLocatizedMessage(){
		return "Wrong Phase.";
	}

}
