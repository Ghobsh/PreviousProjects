package eg.edu.guc.yugioh.exceptions;

public class MonsterMultipleAttackException extends RuntimeException{

	
	
	public MonsterMultipleAttackException(){
		super("This monster attacked succesfully, you can't attack with it again this turn");
		
	}
	
//	public String getLocalizedMessage(){
//		return MonsterName + " has already attacked this turn, please wait until the next turn to attack with it again";
//	}

}
