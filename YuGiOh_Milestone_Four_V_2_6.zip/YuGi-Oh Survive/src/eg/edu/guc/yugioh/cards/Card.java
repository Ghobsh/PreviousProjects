package eg.edu.guc.yugioh.cards;

import java.io.FileNotFoundException;

import eg.edu.guc.yugioh.board.Board;

abstract public class Card implements Cloneable {
	

	final private String name, description, pic;
	
	private boolean isHidden;
	private Location location;
	private static Board board;
	
	public Card(String name, String description, String pic) {
		this.pic=pic;
		this.name = name;
		this.description = description;
		isHidden=true;
		location = Location.DECK;
	}
	
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
	}
	
	public String getName(){
		return name;
	}
	
	public String getDescription(){
		return description;
	}
	
	public Location getLocation(){
		return location;
	}
	
	public void setLocation(Location l){
		location = l;
	}
	
	public static Board getBoard(){
		return board;
	}
	
	public static void setBoard(Board b){
		board = b;
	}
	
	public boolean isHidden(){
		return isHidden;
	}
	
	public void setHidden(boolean ih){
		isHidden=ih;
	}
	
	
	
	
	
	/*
	public boolean getIsHidden(){
		return isHidden;
	}
	
	
	
	
	public void setLocation(Location l){
		location = l;
	}
	
	public Location getLocation(){
		return location;
	}
	
	
	
	
	
	public Board getBoard(){
		return board;
	}
	
	public void setBoard(Board b){
		board = b;
	}

	*/
	
	
	//XXX abstract method because every card has an action, but they are different from one another
	
	abstract public void action(MonsterCard monster) throws FileNotFoundException, CloneNotSupportedException;

	public String getPic() {
		return pic;
	}

}
