package eg.edu.guc.yugioh.cards;

import java.io.FileNotFoundException;

public class MonsterCard extends Card implements Cloneable {

	
	
	
	private int level, defensePoints, attackPoints;
	private Mode mode;
	
	

	public MonsterCard(String name, String description , int level, int attack, int defense,String pic){
		super(name, description ,pic);
		this.level = level;
		attackPoints = attack;
		defensePoints = defense;
		mode = Mode.DEFENSE;
	}
	
	public String toString(){
		return getName()+getDescription()+getAttackPoints()+getDefensePoints()+getLevel()+getLocation();
	}
	
	public Object clone() throws CloneNotSupportedException{
		MonsterCard monster = (MonsterCard) super.clone();
		monster.setAttackPoints(this.getAttackPoints());
		monster.setDefensePoints(defensePoints);
		monster.setHidden(isHidden());
		monster.setLocation(getLocation());
		monster.setMode(this.mode);
		
		return monster;
	}
	
	
	
	
	public int getDefensePoints() {
		return defensePoints;
	}

	public void setDefensePoints(int defensePoints) {
		this.defensePoints = defensePoints;
	}

	
	
	
	
	
	public int getAttackPoints() {
		return attackPoints;
	}

	public void setAttackPoints(int attackPoints) {
		this.attackPoints = attackPoints;
	}

	
	
	
	public int getLevel() {
		return level;
	}
	
	
	
	

	public Mode getMode() {
		return mode;
	}
	
	public void setMode(Mode m){
		mode = m;
	}

	public void action(MonsterCard monster){
		
		if(this.getMode()!=Mode.DEFENSE)
		Card.getBoard().getActivePlayer().declareAttack(this, monster);
		
	}
	
	public void action(){
		
		if(this.getMode()!=Mode.DEFENSE)
		Card.getBoard().getActivePlayer().declareAttack(this);
	
	}
	
	
	
	
	
	

	
	
}
