package eg.edu.guc.yugioh.cards.spells;

import java.io.FileNotFoundException;

import eg.edu.guc.yugioh.board.player.Field;
import eg.edu.guc.yugioh.cards.Location;
import eg.edu.guc.yugioh.cards.Mode;
import eg.edu.guc.yugioh.cards.MonsterCard;
import eg.edu.guc.yugioh.gui.ActiveField;

public class MonsterReborn extends SpellCard{

	public MonsterReborn(String n, String d,String pic)  {
		super(n,d, pic);
	}
		
	
	public void action(MonsterCard monster) {
		MonsterCard x = getBoard().getActivePlayer().getField().getBestOfGrave();
		MonsterCard y = getBoard().getOpponentPlayer().getField().getBestOfGrave();
		
		//TODO What if the monster area was already full, do I need to handle this now?
		
		if(y==null && x != null){
			getBoard().getActivePlayer().getField().getMonstersArea().add(x);
			x.setLocation(Location.FIELD);
			Field.addMonsterPicToField(x, true);
			getBoard().getActivePlayer().getField().getGraveyard().remove(x);
			x.setMode(Mode.ATTACK);
		} else {
			if(y!=null && x == null){
				getBoard().getActivePlayer().getField().getMonstersArea().add(y);
				y.setLocation(Location.FIELD);
				Field.addMonsterPicToField(x, true);
				getBoard().getOpponentPlayer().getField().getGraveyard().remove(y);
				y.setMode(Mode.ATTACK);
			} else {
				if(x.getAttackPoints()>y.getAttackPoints()){
					getBoard().getActivePlayer().getField().getMonstersArea().add(x);
					x.setLocation(Location.FIELD);
					Field.addMonsterPicToField(x, true);
					getBoard().getActivePlayer().getField().getGraveyard().remove(x);
					x.setMode(Mode.ATTACK);
				}else{
					getBoard().getActivePlayer().getField().getMonstersArea().add(y);
					y.setLocation(Location.FIELD);
					Field.addMonsterPicToField(x, true);
					getBoard().getOpponentPlayer().getField().getGraveyard().remove(y);
					y.setMode(Mode.ATTACK);
				}
			}
		}
		
		
	}

}
