package eg.edu.guc.yugioh.cards.spells;

import java.io.FileNotFoundException;

import eg.edu.guc.yugioh.board.player.Field;
import eg.edu.guc.yugioh.cards.MonsterCard;

public class Raigeki extends SpellCard{

	public Raigeki(String n, String d,String pic)  {
		super(n,d, pic);
	}
	
	
	
	public void action(MonsterCard monster){
		
		Field f = getBoard().getOpponentPlayer().getField();
		f.removeMonsterToGraveyard(f.getMonstersArea());
		
		
	}

}
