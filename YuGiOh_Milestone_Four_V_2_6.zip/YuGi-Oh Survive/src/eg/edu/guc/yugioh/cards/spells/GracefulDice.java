package eg.edu.guc.yugioh.cards.spells;

import java.io.FileNotFoundException;





import java.util.ArrayList;
import java.util.Random;







import eg.edu.guc.yugioh.board.Board;
import eg.edu.guc.yugioh.board.player.Player;
import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.Mode;
import eg.edu.guc.yugioh.cards.MonsterCard;

public class GracefulDice extends SpellCard{

	
	
	public GracefulDice(String n, String d,String pic)  {
		super(n,d, pic);
	}


	
	
	
	public void action(MonsterCard Monster) {
		
		
		getBoard().getActivePlayer().getField().addRandomFactorToMyMonsters();


		
		
		
		
		
		
		
		
		
		
	/*int x = (int) (Math.random()*10 + 1);

	int y = x*100;


	for (int i =0; i<getBoard().getActivePlayer().getField().getMonstersArea().size(); i++) {
		
		MonsterCard d = (MonsterCard) getBoard().getActivePlayer().getField().getMonstersArea().get(i);
		
		int att = d.getAttackPoints()+y;
		int def = d.getDefensePoints()+y;
		
		d.setAttackPoints(att);
		d.setDefensePoints(def);*/
			
			
			
			
			
			
			
			
			
			
			
			
			
			
//			ArrayList<MonsterCard> f=getBoard().getActivePlayer().getField().getMonstersArea();
//			int points=(myRandomizer(10)+1)*100;
//			for (int i = 0; i < f.size(); i++) {
//				f.get(i).setAttackPoints((f.get(i).getAttackPoints())+points);
//				f.get(i).setDefensePoints((f.get(i).getDefensePoints())+points);
//			}
//			
//		}
//	
//		private int myRandomizer(int n) {
//			Random rn=new Random();
//			return rn.nextInt(n);
//		}
//		
		
			
		
//		ArrayList<MonsterCard> f=getBoard().getActivePlayer().getField().getMonstersArea();
//		
//		int x = (int) (Math.random()*10 + 1);
//		
//		int y = x*100;
//		
//		
//		for (int i =0; i<getBoard().getActivePlayer().getField().getMonstersArea().size(); i++) {
//			f.get(i).setAttackPoints(f.get(i).getAttackPoints()+y);
//			f.get(i).setDefensePoints(f.get(i).getDefensePoints()+y);
//		}
//		
	
		
//		
//		
//		super.action(Monster);
//		ArrayList<MonsterCard> f=getBoard().getActivePlayer().getField().getMonstersArea();
//		int points=(myRandomizer(10)+1)*100;
//		for (int i = 0; i < f.size(); i++) {
//			f.get(i).setAttackPoints((f.get(i).getAttackPoints())+points);
//			f.get(i).setDefensePoints((f.get(i).getDefensePoints())+points);
//		}
//		
//	}
//	
//	private int myRandomizer(int n) {
//		Random rn=new Random();
//		return rn.nextInt(n);
//	}
//		
//		
	
		
		
		
		
		
		}
	
//	public static void main(String[] args) throws CloneNotSupportedException, NumberFormatException, FileNotFoundException {
//		try{
//		Player p1 = new Player("Yugi");
//		Player p2 = new Player("Kaiba");
//		Board b = new Board();
//		b.startGame(p1, p2);
//		} catch (Exception e){
//			
//		}
//
//		
//		MonsterCard blueEyes = new MonsterCard("Blue Eyes", "Legendary dragon",
//				4, 2000, 1500);
//		MonsterCard blueEyes2 = new MonsterCard("Blue Eyes2", "Legendary dragons",
//				6, 3000, 2500);
//		MonsterCard blueEyes3 = new MonsterCard("Blue Eyes3", "Legendary dragonss",
//				8, 4000, 3500);
//		MonsterCard blueEyes4 = new MonsterCard("Blue Eyes4", "Legendary dragonss",
//				8, 5000, 4500);
//		
//		MonsterCard blueEyes5 = new MonsterCard("Blue Eyes5", "Legendary dragon",
//				4, 2000, 1500);
//		MonsterCard blueEyes6 = new MonsterCard("Blue Eyes6", "Legendary dragons",
//				6, 3000, 2500);
//		MonsterCard blueEyes7 = new MonsterCard("Blue Eyes7", "Legendary dragonss",
//				8, 4000, 3500);
//		MonsterCard blueEyes8 = new MonsterCard("Blue Eyes8", "Legendary dragonss",
//				8, 5000, 4500);
//
//		
//		GracefulDice c3 = new GracefulDice("MagePower", "MP");
//
//		Card.getBoard().getActivePlayer().getField().addMonsterToField(blueEyes, Mode.ATTACK, false);
//		Card.getBoard().getActivePlayer().getField().addMonsterToField(blueEyes2, Mode.ATTACK, false);
//		Card.getBoard().getActivePlayer().getField().addMonsterToField(blueEyes3, Mode.ATTACK, false);
//		Card.getBoard().getActivePlayer().getField().addMonsterToField(blueEyes4, Mode.ATTACK, false);
//		
//
//		Card.getBoard().getOpponentPlayer().getField().addMonsterToField(blueEyes5, Mode.ATTACK, false);
//		Card.getBoard().getOpponentPlayer().getField().addMonsterToField(blueEyes6, Mode.ATTACK, false);
//		Card.getBoard().getOpponentPlayer().getField().addMonsterToField(blueEyes7, Mode.ATTACK, false);
//		Card.getBoard().getOpponentPlayer().getField().addMonsterToField(blueEyes8, Mode.ATTACK, false);
//
//		
//
//		c3.action(null);
//		
//		for (int i = 0; i <Card.getBoard().getActivePlayer().getField().getMonstersArea().size(); i++) {
//			System.out.println(Card.getBoard().getActivePlayer().getField().getMonstersArea().get(i).getName()+": "+Card.getBoard().getActivePlayer().getField().getMonstersArea().get(i).getAttackPoints()+"   "+Card.getBoard().getActivePlayer().getField().getMonstersArea().get(i).getName()+": "+Card.getBoard().getActivePlayer().getField().getMonstersArea().get(i).getDefensePoints());
//		}
//		System.out.println();
//		for (int i = 0; i <Card.getBoard().getOpponentPlayer().getField().getMonstersArea().size(); i++) {
//			System.out.println(Card.getBoard().getOpponentPlayer().getField().getMonstersArea().get(i).getName()+": "+Card.getBoard().getOpponentPlayer().getField().getMonstersArea().get(i).getAttackPoints());
//		}
//
//	}
//		
//		




		}
