package eg.edu.guc.yugioh.cards.spells;

import java.io.FileNotFoundException;

import eg.edu.guc.yugioh.board.player.Field;
import eg.edu.guc.yugioh.cards.MonsterCard;

public class DarkHole extends Raigeki {

	public DarkHole(String n, String d,String pic)  {
		super(n,d, pic);
	}
	
	public void action(MonsterCard monster){
		
		super.action(monster);
		
		Field f =getBoard().getActivePlayer().getField();
		f.removeMonsterToGraveyard(f.getMonstersArea());
		
		
		
	}

}
