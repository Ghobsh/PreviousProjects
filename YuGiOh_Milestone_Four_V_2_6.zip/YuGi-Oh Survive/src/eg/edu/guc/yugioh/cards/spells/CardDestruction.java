package eg.edu.guc.yugioh.cards.spells;

import java.io.FileNotFoundException;

import eg.edu.guc.yugioh.board.player.Field;
import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.MonsterCard;

public class CardDestruction extends SpellCard{

	public CardDestruction(String n, String d, String pic){
		super(n,d, pic);
	}


	public void action(MonsterCard monster){
		boolean activeWins = false;
		boolean opponentWins = false;

		Field activeField = getBoard().getActivePlayer().getField();
		Field opponentField = getBoard().getOpponentPlayer().getField();

		int xactive = activeField.getHand().size();
		int xopponent = opponentField.getHand().size();

		activeField.discardHand();
		opponentField.discardHand();

		activeField.addNCardsToHand(xactive);

		if(Card.getBoard().getWinner()!=null ){
			opponentWins=true;
		}
		opponentField.addNCardsToHand(xopponent);
		
		if(opponentWins){
			
				Card.getBoard().setWinner(Card.getBoard().getOpponentPlayer());
			
		}

	}


}
