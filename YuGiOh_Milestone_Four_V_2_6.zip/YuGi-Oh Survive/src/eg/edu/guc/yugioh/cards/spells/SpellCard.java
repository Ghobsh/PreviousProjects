package eg.edu.guc.yugioh.cards.spells;
import java.io.FileNotFoundException;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.MonsterCard;

abstract public class SpellCard extends Card implements Cloneable {

	public SpellCard(String name, String description, String pic) {
		super(name, description, pic);
	}
	
	
	abstract public void action(MonsterCard monster);
	
	
	public Object clone() throws CloneNotSupportedException{
		SpellCard spell = (SpellCard) super.clone();
		return spell;
	}
	
	
	
	
}
