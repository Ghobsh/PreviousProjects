package eg.edu.guc.yugioh.listeners;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import eg.edu.guc.yugioh.gui.InfoPanel;

public class GraveHover implements MouseListener{

	public void mouseClicked(MouseEvent e) {
		// TODO 
		
	}

	public void mouseEntered(MouseEvent e) {
		InfoPanel.changeGrave(e.getSource());
	}

	public void mouseExited(MouseEvent arg0) {
		
	}

	public void mousePressed(MouseEvent arg0) {
		
	}

	public void mouseReleased(MouseEvent arg0) {
		
	}

}
