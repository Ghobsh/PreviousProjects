package eg.edu.guc.yugioh.listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import eg.edu.guc.yugioh.cards.Card;

public class EndTurnListener implements ActionListener{

	public void actionPerformed(ActionEvent arg0) {
		Card.getBoard().getActivePlayer().endTurn();
	}

}
