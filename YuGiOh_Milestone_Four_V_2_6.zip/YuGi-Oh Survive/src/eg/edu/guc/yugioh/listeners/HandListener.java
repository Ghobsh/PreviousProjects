package eg.edu.guc.yugioh.listeners;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.MonsterCard;
import eg.edu.guc.yugioh.cards.spells.ChangeOfHeart;
import eg.edu.guc.yugioh.cards.spells.MagePower;
import eg.edu.guc.yugioh.cards.spells.MonsterReborn;
import eg.edu.guc.yugioh.cards.spells.SpellCard;
import eg.edu.guc.yugioh.gui.ActiveField;
import eg.edu.guc.yugioh.gui.HLabel;
import eg.edu.guc.yugioh.gui.HoverableLabel;
import eg.edu.guc.yugioh.gui.InfoPanel;
import eg.edu.guc.yugioh.gui.OpponentField;

public class HandListener implements MouseListener{ // TODO CHECK IF THE CONDITIONS OF TRIBUTE SUMMON ARE CORRECT


	MonsterCard Specialist = null;
	MonsterCard summonTarget = null;
	MonsterCard actionTarget = null;
	ArrayList<MonsterCard> sacrifices = new ArrayList<MonsterCard>();

	SpellCard spell = null;
	boolean wannaSet = false;

	public HandListener(){
	}

	public void ref(){
		Specialist = null;
		summonTarget = null;
		actionTarget= null;
		sacrifices.clear();
		spell=null;
		wannaSet = false;
	}

	public void mouseClicked(MouseEvent e) {
		try{
			if(e.getButton()==MouseEvent.BUTTON2){


				this.ref();

			} else {

				if(ActiveField.getHand().contains(((HoverableLabel) e.getSource()))){

					if(((HoverableLabel) e.getSource()).getX2() instanceof SpellCard){

						if(e.getButton()==MouseEvent.BUTTON3){

							Card.getBoard().getActivePlayer().setSpell((SpellCard) ((HoverableLabel) e.getSource()).getX2());

						} else { // XXX TRYING TO ACTIVATE SPELLS NOW

							if(!(((HoverableLabel) e.getSource()).getX2() instanceof ChangeOfHeart || ((HoverableLabel) e.getSource()).getX2() instanceof MagePower)){

								Card.getBoard().getActivePlayer().activateSpell((SpellCard) ((HoverableLabel) e.getSource()).getX2(), null);

							} else {
								spell = (SpellCard) ((HoverableLabel) e.getSource()).getX2();
								System.out.println("saved spell" + spell.getName());
							}
						}
					} else { //XXX HANDLING MONSTERCARDS NOW

						if(e.getButton()==MouseEvent.BUTTON3){ //XXX HANDLING SETTING MONSTERS 

							if(((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() <= 4){ // XXX HANDLING LOW LEVEL MONSTERS

								Card.getBoard().getActivePlayer().setMonster((MonsterCard) ((HoverableLabel) e.getSource()).getX2());

							} else {
								//if((((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel()-3)/2 < Card.getBoard().getActivePlayer().getField().getMonstersArea().size())
								if( ((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() <7 && ((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() >4 && Card.getBoard().getActivePlayer().getField().getMonstersArea().size() == 1 || ((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() <9 && ((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() >6 && Card.getBoard().getActivePlayer().getField().getMonstersArea().size() == 2){ 
									summonTarget = (MonsterCard) ((HoverableLabel) e.getSource()).getX2();
									wannaSet = true;
									System.out.println("sn " + summonTarget.getName());
								}
							}
						} else { // XXX NOW THE NORMAL SUMMON

							if(((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() <= 4){ // XXX HANDLING LOW LEVEL MONSTERS

								Card.getBoard().getActivePlayer().summonMonster((MonsterCard) ((HoverableLabel) e.getSource()).getX2());

							} else {
								if(((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() <7 && ((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() >4 && Card.getBoard().getActivePlayer().getField().getMonstersArea().size() == 1 || ((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() <9 && ((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() >6 && Card.getBoard().getActivePlayer().getField().getMonstersArea().size() == 2){
									summonTarget = (MonsterCard) ((HoverableLabel) e.getSource()).getX2();
									System.out.println("sn "+ summonTarget.getName());
								}
							}
						}
					}


				}

				else { // NOW HANDLING CLICKS ON FIELD SPELLS 

					if(ActiveField.getSpell().contains(((HoverableLabel) e.getSource()))){

						if(!(((HoverableLabel) e.getSource()).getX2() instanceof ChangeOfHeart || ((HoverableLabel) e.getSource()).getX2() instanceof MagePower)){

							Card.getBoard().getActivePlayer().activateSpell((SpellCard) ((HoverableLabel) e.getSource()).getX2(), null);

						} else {
							spell = (SpellCard) ((HoverableLabel) e.getSource()).getX2();
							System.out.println("saved spell " + spell.getName());
						}
					}


					else { // HANDLING THE CLICK ON FIELD MONSTERS

						if(ActiveField.getMonster().contains(((HoverableLabel) e.getSource()))){

							if(e.getButton()==MouseEvent.BUTTON3){ //XXX RIGHT CLICK = SWITCH MONSTERS

								Card.getBoard().getActivePlayer().switchMonsterMode((MonsterCard) ((HoverableLabel) e.getSource()).getX2());

							} else { //XXX LEFT CLICK : WARNING, OBNOXIOUS WHORE.

								if(summonTarget != null){ //FIRST CASE: IF YOU'RE GONNA SACRIFICE
									sacrifices.add((MonsterCard) ((HoverableLabel) e.getSource()).getX2());
									System.out.println("Sac: " + sacrifices.get(sacrifices.size()-1).getName());

									if(((((MonsterCard) summonTarget).getLevel() ==5 || ((MonsterCard) summonTarget).getLevel() ==6) && sacrifices.size() == 1) || ((((MonsterCard) summonTarget).getLevel() ==8 || ((MonsterCard) summonTarget).getLevel() ==7) && sacrifices.size() == 2)){
										if(!wannaSet)
											Card.getBoard().getActivePlayer().summonMonster(summonTarget, sacrifices);
										else
											Card.getBoard().getActivePlayer().setMonster(summonTarget, sacrifices);
										ref();
									}

								} else {
									if(spell!= null){
										if(spell instanceof MagePower){
											Card.getBoard().getActivePlayer().activateSpell(spell, (MonsterCard) ((HoverableLabel) e.getSource()).getX2());

										}


									}else { //WANNA ATTACK?? 

										if(Card.getBoard().getOpponentPlayer().getField().getMonstersArea().isEmpty()){ //DIRECT ATTACK

											Card.getBoard().getActivePlayer().declareAttack((MonsterCard) ((HoverableLabel) e.getSource()).getX2());

										} else { //TARGETED ATTACK BA2A

											if(spell !=null){
												if(spell instanceof MagePower){
													Card.getBoard().getActivePlayer().activateSpell(spell, (MonsterCard) ((HoverableLabel) e.getSource()).getX2());
													ref();
												}
											} else {
												Specialist = (MonsterCard) ((HoverableLabel) e.getSource()).getX2();
												System.out.println(Specialist.getName());
											}
										}
									}
								}
							}
						}else { // XXX TARGETING AN OPPONENT MONSTER

							if(OpponentField.getMonster().contains(((HoverableLabel) e.getSource()))){
								if(Specialist!=null){
									Card.getBoard().getActivePlayer().declareAttack(Specialist, (MonsterCard) ((HoverableLabel) e.getSource()).getX2());
									System.out.println("attack");
									ref();
								} else {
									if(spell != null)
										if(spell instanceof ChangeOfHeart){
											Card.getBoard().getActivePlayer().activateSpell(spell, (MonsterCard) ((HoverableLabel) e.getSource()).getX2());
											System.out.println("heart change");
											ref();
										}
								}
							}
						}
					}

				}

			}

		} catch (Exception e1){
			JOptionPane.showMessageDialog(null, e1.getMessage());
		}

	}



























	/**	if(Card.getBoard().getActivePlayer().getField().getHand().contains((Card) ((HoverableLabel) e.getSource()).getX2())){
			if (e.getButton() == MouseEvent.BUTTON3) {
				if(((HoverableLabel) e.getSource()).getX2() instanceof SpellCard)
					Card.getBoard().getActivePlayer().setSpell((SpellCard)((HoverableLabel) e.getSource()).getX2());
				else{ 
					if(summonTarget == null){
						if(((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() <=4){
							Card.getBoard().getActivePlayer().setMonster((MonsterCard) ((HoverableLabel) e.getSource()).getX2());
						} else {
//							if((((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() <4 && ((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() >4 && sacrifices.size() == 1) || (((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() <=8 && ((MonsterCard) ((HoverableLabel) e.getSource()).getX2()).getLevel() >=7 && sacrifices.size()==2)){
//								Card.getBoard().getActivePlayer().setMonster(((HoverableLabel) e.getSource()).getX2(), sacrifices);
//							}
							summonTarget = (MonsterCard) ((HoverableLabel) e.getSource()).getX2();
						}
					} 
				}
			} else {
				if (((HoverableLabel) e.getSource()).getX2() instanceof MonsterCard){
					Card.getBoard().getActivePlayer().summonMonster((MonsterCard)((HoverableLabel) e.getSource()).getX2());
				} else {
					//Card.getBoard().getActivePlayer().activateSpell(((SpellCard)((HoverableLabel) e.getSource()).getX2()), ); TODO ACTIVATE SPELL HERE.
				}
			}
		} else {
			if(Card.getBoard().getActivePlayer().getField().getMonstersArea().contains((MonsterCard) ((HoverableLabel) e.getSource()).getX2())){
				if (e.getButton() == MouseEvent.BUTTON3) {
					Card.getBoard().getActivePlayer().switchMonsterMode(((MonsterCard) ((HoverableLabel) e.getSource()).getX2()));
				}else {
					//Card.getBoard().getActivePlayer().summonMonster((MonsterCard)((HoverableLabel) e.getSource()).getX2()); TODO MAKE IT ATTACK
				} 
			}
		}

	 *
	 *
	 *
	//	* TODO ONCE OUT OF COMMENT, IF EVER, PUT THEM IN MOUSECLICKED AGAIN.
	 */



	public void mouseEntered(MouseEvent arg0) {
		InfoPanel.change(arg0.getSource());
	}

	public void mouseExited(MouseEvent arg0) {

	}

	public void mousePressed(MouseEvent arg0) {

	}

	public void mouseReleased(MouseEvent arg0) {

	}

}
