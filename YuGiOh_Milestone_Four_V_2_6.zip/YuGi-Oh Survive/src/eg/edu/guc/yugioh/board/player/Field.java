package eg.edu.guc.yugioh.board.player;
import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.Location;
import eg.edu.guc.yugioh.cards.MonsterCard;
import eg.edu.guc.yugioh.cards.Mode;
import eg.edu.guc.yugioh.cards.spells.SpellCard;
import eg.edu.guc.yugioh.exceptions.UnexpectedFormatException;
import eg.edu.guc.yugioh.gui.ActiveField;
import eg.edu.guc.yugioh.gui.HLabel;
import eg.edu.guc.yugioh.gui.GUIBoard;
import eg.edu.guc.yugioh.gui.HoverableLabel;
import eg.edu.guc.yugioh.gui.Interface;
import eg.edu.guc.yugioh.gui.MLabel;
import eg.edu.guc.yugioh.gui.OpponentField;
import eg.edu.guc.yugioh.gui.SLabel;
import eg.edu.guc.yugioh.gui.TempoPanel;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Field {  



	private ArrayList<MonsterCard> monstersArea = new ArrayList<MonsterCard>();

	static GUIBoard inter;

	public static GUIBoard getInter() {
		return inter;
	}

	public static void setInter(GUIBoard inter) {
		Field.inter = inter;
	}




	private ArrayList<SpellCard> spellArea = new ArrayList<SpellCard>();


	private ArrayList<Card> hand = new ArrayList<Card>();
	private ArrayList<Card> graveyard = new ArrayList<Card>();

	private Deck deck;
	private Phase phase;








	public void setPhase(Phase p){
		phase=p;
	}

	public Phase getPhase(){
		return phase;
	}







	public ArrayList<MonsterCard> getMonstersArea() {
		return monstersArea;
	}



	public ArrayList<SpellCard> getSpellArea() {
		return spellArea;
	}



	public ArrayList<Card> getHand() {
		return hand;
	}

	public ArrayList<Card> getGraveyard() {
		return graveyard;
	}

	public void setDeck(Deck deck) {
		this.deck = deck;
	}

	public Deck getDeck(){
		return deck;
	}

	public Field() throws IOException, UnexpectedFormatException {
		phase = Phase.MAIN1;
		deck=new Deck();
	}





	public void addMonsterToField(MonsterCard monster, Mode m, boolean isHidden){

		if(monstersArea.size()<5){

			monster.setMode(m);
			monster.setHidden(isHidden);
			monster.setLocation(Location.FIELD);

			monstersArea.add(monster);
			hand.remove(monster);
		}
	}





	public void addMonsterToField(MonsterCard monster, Mode m, ArrayList<MonsterCard> sacrifices){

		if(monster.getLevel()==5||monster.getLevel()==6){

			if(sacrifices.size()==1){

				removeMonsterPicFromField(sacrifices.get(0));
				removeMonsterToGraveyard(sacrifices.get(0));



				addMonsterToField(monster, m, m==Mode.DEFENSE);
				addMonsterPicToField(monster, m==Mode.ATTACK);

			}
		} else {
			if(monster.getLevel()==7||monster.getLevel()==8){

				if(sacrifices.size()==2){

					sacrifices.get(0).setLocation(Location.GRAVEYARD);
					graveyard.add(sacrifices.get(0)); 
					removeMonsterPicFromField(sacrifices.get(0));
					monstersArea.remove(sacrifices.remove(0));

					sacrifices.get(0).setLocation(Location.GRAVEYARD);
					graveyard.add(sacrifices.get(0)); 
					removeMonsterPicFromField(sacrifices.get(0));
					monstersArea.remove(sacrifices.remove(0));

					addMonsterToField(monster, m, m==Mode.DEFENSE);
					addMonsterPicToField(monster, m==Mode.ATTACK);
				}		
			}
		}
	}




	public void addRandomFactorToMyMonsters(){
		int x = (int) (Math.random()*10) + 1;

		//int y = x*100;

		for (int i =0; i<monstersArea.size(); i++) {

			MonsterCard d =  monstersArea.get(i);

			int att = monstersArea.get(i).getAttackPoints();
			int def = monstersArea.get(i).getDefensePoints();

			d.setAttackPoints(att+(x*100));
			d.setDefensePoints(def+(x*100));
		}
	}


	public void removeMonsterToGraveyard(MonsterCard monster){
		if(monstersArea.contains(monster)){
			monster.setLocation(Location.GRAVEYARD);
			graveyard.add(monster);

			if(Card.getBoard().getOpponentPlayer().getField().getMonstersArea().contains(monster)){

				removeMonsterPicFromOppField(monster);
				//				addCardPicToOppGraveyard(monster);

			} else {

				removeMonsterPicFromField(monster);
				//				addCardPicToGraveyard(monster);

			}
			monstersArea.remove(monster);
		}
	}





	public void removeMonsterToGraveyard(ArrayList<MonsterCard> monster){
		while(!monster.isEmpty()){
			monster.get(0).setLocation(Location.GRAVEYARD);
			graveyard.add(monster.get(0)); 

			removeMonsterPicFromField(monster.get(0));
			removeMonsterPicFromOppField(monster.get(0));
			//			addCardPicToGraveyard(monster.get(0));
			monstersArea.remove(monster.remove(0));
		}
	}



	public void discardHand(){
		while(!hand.isEmpty()){
			hand.get(0).setLocation(Location.GRAVEYARD);
			removeCardPicFromHand(hand.get(0));
			addCardPicToGraveyard(hand.get(0));
			graveyard.add(hand.remove(0));

		}
	}


	public void addSpellToField(SpellCard action, MonsterCard monster, boolean hidden){
		if(spellArea.size()<5){
			action.setHidden(hidden);
			action.setLocation(Location.FIELD);
			spellArea.add(action);
			hand.remove(action);

			addSpellPicToField(action, !hidden);
			removeSpellPicFromHand(action);

			if(!hidden){
				action.action(monster); action.setLocation(Location.GRAVEYARD);
				removeSpellToGraveyard(action);
			}

		}
	}






	public void activateSetSpell(SpellCard action, MonsterCard monster) {
		if(spellArea.contains(action)){
			action.setHidden(false);
			action.action(monster);
			action.setLocation(Location.GRAVEYARD);
			spellArea.remove(action);
			graveyard.add(action);

			if(Card.getBoard().getActivePlayer() == Interface.ini1){
				removeSpellPicFromField(action);
			} else {
				removeSpellPicFromOppField(action);
			}
			//			addCardPicToGraveyard(action);
		}
	}




	public void removeSpellToGraveyard(SpellCard spell){
		if(spellArea.contains(spell)){
			spell.setLocation(Location.GRAVEYARD);
			graveyard.add(spell);
			spellArea.remove(spell);

			removeSpellPicFromField(spell);
			//			addCardPicToGraveyard(spell);
		}
	}





	public void removeSpellToGraveyard(ArrayList<SpellCard> spells){
		while(!spells.isEmpty()){
			SpellCard s = spells.get(0);
			s.setLocation(Location.GRAVEYARD);
			graveyard.add(s); 
			spells.remove(s);
			spellArea.remove(s);

			removeSpellPicFromField(s);
			//			addCardPicToGraveyard(s);
		}
	}



	public void addNCardsToHand(int n){
		for (int i = 0; i < n; i++) {
			addCardToHand();
		}
	}


	public void addCardToHand(){
		if(deck.getDeck().size()<1){
			Card.getBoard().setWinner((this.equals(Card.getBoard().getActivePlayer().getField())? Card.getBoard().getOpponentPlayer():Card.getBoard().getActivePlayer()));
			Player.WinWin();
			return;
		}
		deck.getDeck().get(0).setLocation(Location.HAND);
		Card c = deck.getDeck().get(0);
		hand.add(c);
		deck.getDeck().remove(0);

		HLabel x = new HLabel(c);
		x.setVisible(true);


		if(this==Card.getBoard().getActivePlayer().getField()){
			change(x,c, true);
			ActiveField.getHand().add(x);
			ActiveField.getHandArea().add(x);
		} else{
			change(x,c, false);
			OpponentField.getHand().add(x);
			OpponentField.getHandArea().add(x);
		}

		//		TempoPanel.refresh();

		inter.repaint();
		inter.validate();

		//		LowerField.LowerHand.add(new MButton("Hand"));
		//		LowerField.hand.add(GUIBoard.lowerCardArea.LowerHand.get(GUIBoard.lowerCardArea.LowerHand.size()-1));

	}

	public static void change(HoverableLabel x, Card c, boolean seen){
		if(seen){
			ImageIcon imageIcon = new ImageIcon(c.getPic());// load the image to a imageIcon
			Image image = imageIcon.getImage(); // transform it 
			Image newimg = image.getScaledInstance(80, 100,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
			imageIcon = new ImageIcon(newimg);  // transform it back
			x.setIcon(imageIcon);
		} else {
			ImageIcon imageIcon = new ImageIcon("Card Back.png");// load the image to a imageIcon
			Image image = imageIcon.getImage(); // transform it 
			Image newimg = (c instanceof MonsterCard)? image.getScaledInstance(100, 80,  java.awt.Image.SCALE_SMOOTH):image.getScaledInstance(80, 100,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
			imageIcon = new ImageIcon(newimg);  // transform it back
			x.setIcon(imageIcon);
		}
	}



	public MonsterCard getBestOfGrave(){
		MonsterCard x = new MonsterCard("test","test",-10000,-100000,9999,"");
		MonsterCard z = x;
		for (int i = 0; i < graveyard.size(); i++) {

			if(graveyard.get(i) instanceof MonsterCard){
				MonsterCard y = (MonsterCard) graveyard.get(i);

				if(y.getAttackPoints()>x.getAttackPoints()){
					x=y;	
				}

			}
		}

		if(z==x)
			return null;

		return x;
	}

	public void removeCardPicFromHand(Card card) {

		for (int i = 0; i < ActiveField.getHand().size(); i++) {
			if(ActiveField.getHand().get(i).getX2() == card){
				ActiveField.getHandArea().remove(ActiveField.getHand().remove(i));
				ActiveField.getHandArea().revalidate();
				ActiveField.getHandArea().repaint();
				break;
			}
		}for (int i = 0; i < OpponentField.getHand().size(); i++) {
			if(OpponentField.getHand().get(i).getX2() == card){
				OpponentField.getHandArea().remove(OpponentField.getHand().remove(i));
				OpponentField.getHandArea().revalidate();
				OpponentField.getHandArea().repaint();
				break;
			}
		}

	}

	public static void addMonsterPicToField(MonsterCard monster, boolean seen) {
		MLabel x = new MLabel(monster);
		change(x,monster, seen);
		ActiveField.getMonster().add(x);
		ActiveField.getMonsterArea().add(x);
	}


	public void removeSpellPicFromHand(SpellCard spell) {

		for (int i = 0; i < ActiveField.getHand().size(); i++) {
			if(ActiveField.getHand().get(i).getX2() == spell){
				ActiveField.getHandArea().remove(ActiveField.getHand().remove(i));
				ActiveField.getHandArea().revalidate();
				ActiveField.getHandArea().repaint();
				break;
			}
		}

	}

	public void addSpellPicToField(SpellCard spell, boolean seen) {

		SLabel x = new SLabel(spell);
		change(x, spell, seen);
		ActiveField.getSpell().add(x);
		ActiveField.getSpellArea().add(x);

	}

	public void removeSpellPicFromField(SpellCard spell) {

		for (int i = 0; i < ActiveField.getSpell().size(); i++) {
			if(ActiveField.getSpell().get(i).getX2() == spell){
				ActiveField.getSpellArea().remove(ActiveField.getSpell().remove(i));
				ActiveField.getSpellArea().revalidate();
				ActiveField.getSpellArea().repaint();
				addCardPicToGraveyard(spell);
				break;
			}
		}



	}

	public static void addCardPicToGraveyard(Card spell) {
		ImageIcon imageIcon = new ImageIcon(spell.getPic());// load the image to a imageIcon
		Image image = imageIcon.getImage(); // transform it 
		Image newimg = image.getScaledInstance(80, 100,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
		imageIcon = new ImageIcon(newimg);  // transform it back

		ActiveField.getActiveGrave().setIcon(imageIcon);

	}



	public void removeMonsterPicFromField(MonsterCard monster) {

		for (int i = 0; i < ActiveField.getMonster().size(); i++) {
			if(ActiveField.getMonster().get(i).getX2() == monster){
				ActiveField.getMonsterArea().remove(ActiveField.getMonster().remove(i));
				ActiveField.getMonsterArea().revalidate();
				ActiveField.getMonsterArea().repaint();
				addCardPicToGraveyard(monster);
			}
		}



	}

	public void removeMonsterPicFromOppField(MonsterCard monster) {
		for (int i = 0; i < OpponentField.getMonster().size(); i++) {
			if(OpponentField.getMonster().get(i).getX2() == monster){
				OpponentField.getMonsterArea().remove(OpponentField.getMonster().get(i));
				OpponentField.getMonsterArea().revalidate();
				OpponentField.getMonsterArea().repaint();
				addCardPicToOppGraveyard(monster);
			}
		}

	}

	private void addCardPicToOppGraveyard(Card monster) {
		ImageIcon imageIcon = new ImageIcon(monster.getPic());// load the image to a imageIcon
		Image image = imageIcon.getImage(); // transform it 
		Image newimg = image.getScaledInstance(80, 100,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
		imageIcon = new ImageIcon(newimg);  // transform it back

		OpponentField.getActiveGrave().setIcon(imageIcon);
	}

	public void changeHiddenToShownDef(MonsterCard c) {
		for (int i = 0; i < OpponentField.getMonster().size(); i++) {
			if(OpponentField.getMonster().get(i).getX2() == c){
				ImageIcon imageIcon = new ImageIcon(c.getPic());// load the image to a imageIcon
				Image image = imageIcon.getImage(); // transform it 
				Image newimg = image.getScaledInstance(100, 80,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
				imageIcon = new ImageIcon(newimg);  // transform it back
				OpponentField.getMonster().get(i).setIcon(imageIcon);
				break;
			}
		}


	}

	public void removeMonsterPicFromOppFieldNoGrave(MonsterCard monster) {
		for (int i = 0; i < OpponentField.getMonster().size(); i++) {
			if(OpponentField.getMonster().get(i).getX2() == monster){
				OpponentField.getMonsterArea().remove(OpponentField.getMonster().get(i));
				OpponentField.getMonsterArea().revalidate();
				OpponentField.getMonsterArea().repaint();
			}
		}

	}

	public static void addCardPicToMyGraveyard(SpellCard spell) {
		ImageIcon imageIcon = new ImageIcon(spell.getPic());// load the image to a imageIcon
		Image image = imageIcon.getImage(); // transform it 
		Image newimg = image.getScaledInstance(80, 100,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
		imageIcon = new ImageIcon(newimg);  // transform it back

		if(Card.getBoard().getActivePlayer() == Interface.ini1 ){
			ActiveField.getActiveGrave().setIcon(imageIcon);

		} else {

			OpponentField.getActiveGrave().setIcon(imageIcon);

		}

	}

	private void removeSpellPicFromOppField(SpellCard spell) {
		for (int i = 0; i < OpponentField.getSpell().size(); i++) {
			if(OpponentField.getSpell().get(i).getX2() == spell){
				OpponentField.getSpellArea().remove(OpponentField.getSpell().remove(i));
				OpponentField.getSpellArea().revalidate();
				OpponentField.getSpellArea().repaint();
				addCardPicToOppGraveyard(spell);
				break;
			}
		}
	}

	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO change type of field labels to mlabel aw slabel
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO

	//TODO
	//TODO
	//TODO
	//TODO
	//TODO
	//TODO


}
