package eg.edu.guc.yugioh.board.player;
import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.MonsterCard;
import eg.edu.guc.yugioh.cards.spells.CardDestruction;
import eg.edu.guc.yugioh.cards.spells.ChangeOfHeart;
import eg.edu.guc.yugioh.cards.spells.DarkHole;
import eg.edu.guc.yugioh.cards.spells.GracefulDice;
import eg.edu.guc.yugioh.cards.spells.HarpieFeatherDuster;
import eg.edu.guc.yugioh.cards.spells.HeavyStorm;
import eg.edu.guc.yugioh.cards.spells.MagePower;
import eg.edu.guc.yugioh.cards.spells.MonsterReborn;
import eg.edu.guc.yugioh.cards.spells.PotOfGreed;
import eg.edu.guc.yugioh.cards.spells.Raigeki;
import eg.edu.guc.yugioh.cards.spells.SpellCard;
import eg.edu.guc.yugioh.exceptions.EmptyFieldException;
import eg.edu.guc.yugioh.exceptions.MissingFieldException;
import eg.edu.guc.yugioh.exceptions.UnexpectedFormatException;
import eg.edu.guc.yugioh.exceptions.UnknownCardTypeException;
import eg.edu.guc.yugioh.exceptions.UnknownSpellCardException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Deck {

	Scanner sc = new Scanner(System.in);

	private static ArrayList<Card> monsters, spells;

	private ArrayList<Card> deck;

	private static boolean readBefore = false; //to check whether cards were loaded before or not.

	private static String monstersPath = "Database-Monsters.csv";
	private static String spellsPath = "Database-Spells.csv";


	/*
	public void loadMonsters() throws NumberFormatException, CloneNotSupportedException, IOException{
		Scanner sc = new Scanner(System.in);
		System.out.println(monsterPrompt);
		Field.setMonstersPath(sc.nextLine());
		int j = 1;
		while(true) {
	
			try {
				monsters = loadCardsFromFile(getMonstersPath());
				break;
			}
	
			catch (FileNotFoundException e){
	
				System.out.println(invalidInputError);
				System.out.println(monsterPrompt);
				Field.setMonstersPath(sc.nextLine());
	
				if(j==2){
					e.printStackTrace();
					break;
				} else {
					j++;
				}
			}
		}
	}
	
	
	public void loadSpells() throws NumberFormatException, CloneNotSupportedException, IOException{
		Scanner sc = new Scanner(System.in);
		System.out.println(spellPrompt);
		Field.setSpellsPath(sc.nextLine());
		int j = 1;
	
		while(true) {
	
			try {
				spells = loadCardsFromFile(getSpellsPath());
				break;
			}
	
			catch (FileNotFoundException e){
				System.out.println(invalidInputError);
				System.out.println(spellPrompt);
				Field.setSpellsPath(sc.nextLine());
	
				if(j==2){
					e.printStackTrace();
					break;
				} else {
					j++;
				}
			}
		}
		sc.close();
	}
	
	 */
	
	private static String monsterPrompt = "Please enter a correct path for monsters: ";

	private static String spellPrompt = "Please enter a correct path for spells: ";

	private static String invalidInputError = "The file was not found";

	private int errorCounter=0;

	/*
	private static int lineCounter=0;

	private static int fieldLocationCounter=0;
	
	private static String spellName="";
	*/


	/*
	public void loadMonsters() throws NumberFormatException, CloneNotSupportedException, IOException{
		Scanner sc = new Scanner(System.in);
		System.out.println(monsterPrompt);
		Field.setMonstersPath(sc.nextLine());
		int j = 1;
		while(true) {

			try {
				monsters = loadCardsFromFile(getMonstersPath());
				break;
			}

			catch (FileNotFoundException e){

				System.out.println(invalidInputError);
				System.out.println(monsterPrompt);
				Field.setMonstersPath(sc.nextLine());

				if(j==2){
					e.printStackTrace();
					break;
				} else {
					j++;
				}
			}
		}
	}


	public void loadSpells() throws NumberFormatException, CloneNotSupportedException, IOException{
		Scanner sc = new Scanner(System.in);
		System.out.println(spellPrompt);
		Field.setSpellsPath(sc.nextLine());
		int j = 1;

		while(true) {

			try {
				spells = loadCardsFromFile(getSpellsPath());
				break;
			}

			catch (FileNotFoundException e){
				System.out.println(invalidInputError);
				System.out.println(spellPrompt);
				Field.setSpellsPath(sc.nextLine());

				if(j==2){
					e.printStackTrace();
					break;
				} else {
					j++;
				}
			}
		}
		sc.close();
	}

	 */

	public void LoadDeck() throws IOException, UnexpectedFormatException{
		int i =0;
		while(true){

			try{
				if(errorCounter>0){
					System.out.println(monsterPrompt);
					setMonstersPath(sc.nextLine());
				}
				monsters=loadCardsFromFile(monstersPath);
				break;

			} catch (FileNotFoundException e){

				if(errorCounter<3){
					System.out.println("FILE NOT FOUND");
					errorCounter++;
				} else {
					throw e;
				}

			} catch (UnknownCardTypeException e){

				if(errorCounter<3){
					System.out.println(invalidInputError);
					errorCounter ++;
				} else {		
					
					throw new UnknownCardTypeException(monstersPath, lineCounter, unknownType);
				}
			
			}  catch (MissingFieldException e){

				if(errorCounter<3){
					System.out.println("MISSINGFIELD");
					errorCounter ++;
				} else {
					throw new MissingFieldException(monstersPath, lineCounter);
				}

			} catch (EmptyFieldException e){

				if(errorCounter<3){
					System.out.println("EMPTYFIELD");
					errorCounter ++;
				} else {
					throw new EmptyFieldException(monstersPath, lineCounter, fieldLocationCounter);
				}

			} 
			i++;
		}
		i=0;
		errorCounter=0;
		while(true){

			try{
				spells=loadCardsFromFile(spellsPath);
				readBefore = true;
				break;

			} catch (FileNotFoundException e){

				if(errorCounter<3){
					System.out.println(invalidInputError);
					System.out.println(spellPrompt);
					setSpellsPath(sc.nextLine());
					errorCounter ++;
				} else {
					
					throw e;
				}

			} catch (UnknownCardTypeException e){

				if(errorCounter<3){
					System.out.println(invalidInputError);
					System.out.println(spellPrompt);
					setSpellsPath(sc.nextLine());
					errorCounter ++;
				} else {
					throw new UnknownCardTypeException(spellsPath, lineCounter, unknownType);
				}
			
			} catch (UnknownSpellCardException e){

				if(errorCounter<3){
					System.out.println(invalidInputError);
					System.out.println(spellPrompt);
					setSpellsPath(sc.nextLine());
					errorCounter ++;
				} else {
					throw new UnknownSpellCardException(spellsPath, lineCounter, unknownSpell);
				}

			} catch (MissingFieldException e){

				if(errorCounter<3){
					System.out.println(invalidInputError);
					System.out.println(spellPrompt);
					setSpellsPath(sc.nextLine());
					errorCounter ++;
				} else {
					throw new MissingFieldException(spellsPath, lineCounter);
				}

			} catch (EmptyFieldException e){

				if(errorCounter<3){
					System.out.println(invalidInputError);
					System.out.println(spellPrompt);
					setSpellsPath(sc.nextLine());
					errorCounter ++;
				} else {
					throw new EmptyFieldException(spellsPath, lineCounter, fieldLocationCounter);
				}
			} 
			i++;
		}

	}


	

	public Deck() throws IOException, UnexpectedFormatException {

		//case list of cards wasn't loaded before.
//		if(!readBefore){ 
			LoadDeck();
			
//		}

			//			monsters = loadCardsFromFile(getMonstersPath());
			//			spells = loadCardsFromFile(getSpellsPath());
			//			loadMonsters();
			//			loadSpells();

			//		}

			deck = new ArrayList<Card>();
			buildDeck(monsters,spells);
		}


	static int lineCounter=0;
	static int fieldLocationCounter=0;
	static String spellName="";
	static String unknownType="";
	static String unknownSpell="";

		public static ArrayList<Card> loadCardsFromFile(String path)throws IOException, UnknownCardTypeException, UnknownSpellCardException, MissingFieldException, EmptyFieldException{

			lineCounter=0;

			fieldLocationCounter=0;
			
			spellName="";
			
			ArrayList<Card> A = new ArrayList<Card>();
			
			lineCounter = 0;
			fieldLocationCounter=0;
			
			String currentLine = "";
			
			FileReader fileReader= new FileReader(path);
			BufferedReader br = new BufferedReader(fileReader);
			
			while ((currentLine = br.readLine()) != null) {
				lineCounter++;
				String [] Params = currentLine.split(",");
				
				
				String x = Params[0]; 
				//first word determined whether this file has Monsters or SpellCards.
				
				
				//adding new card
				if(x.equals("Monster")){
					
					if(Params.length!=7){
						
						throw new MissingFieldException(path, lineCounter);
						
					} 
					
					for (int i = 0; i < Params.length; i++) {
						fieldLocationCounter = i+1;
						if(Params[i].equals("") || Params[i].trim().length() == 0){
							throw new EmptyFieldException(path, lineCounter, i+1);
							
						}
					}
					
					A.add(new MonsterCard(Params[1], Params[2], Integer.parseInt(Params[5]), Integer.parseInt(Params[3]), Integer.parseInt(Params[4]),Params[6]));
				}else{
					if(x.equals("Spell")){
						
						if(Params.length!=4){
							throw new MissingFieldException(path, lineCounter);
						} 
						
						String y = Params[1];

						
						
						for (int i = 0; i < Params.length; i++) {
							fieldLocationCounter = i+1;
							if(Params[i].equals("") || Params[i].trim().length() == 0){
								throw new EmptyFieldException(path, lineCounter, i+1);
								
							}
						}
						unknownSpell = y;
						if (y.equals("Card Destruction")){
							A.add(new CardDestruction(Params[1], Params[2], Params[3]));	
						}else{
							if (y.equals("Harpie's Feather Duster")){
								A.add(new HarpieFeatherDuster(Params[1],Params[2], Params[3]));
							} else{ 
								if (y.equals("Change Of Heart")){ 
									A.add(new ChangeOfHeart(Params[1],Params[2], Params[3]));
								} else{ 
									if (y.equals("Dark Hole")){
										A.add(new DarkHole(Params[1],Params[2], Params[3]));
									} else{
										if (y.equals("Graceful Dice")){
											A.add(new GracefulDice(Params[1],Params[2], Params[3]));
										} else{ 
											if (y.equals("Heavy Storm")){
												A.add(new HeavyStorm(Params[1], Params[2], Params[3]));
											} else{ 
												if (y.equals("Mage Power")){
													A.add(new MagePower(Params[1],Params[2], Params[3]));
												} else{ 
													if (y.equals("Monster Reborn")){
														A.add(new MonsterReborn(Params[1],Params[2], Params[3]));
													} else{
														if (y.equals("Pot of Greed")){ 
															A.add(new PotOfGreed(Params[1],Params[2], Params[3]));
														} else{
															if (y.equals("Raigeki")){
																A.add(new Raigeki(Params[1],Params[2], Params[3]));

															} else {
																throw new UnknownSpellCardException(path, lineCounter, y);
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					} else {
						unknownType=Params[0];
						throw new UnknownCardTypeException(path, lineCounter, Params[0]);
					}
				}
			}


			
			br.close();
			return A;
		}


		public void buildDeck(ArrayList<Card> monsters, ArrayList<Card> spells){

			//adding 15 random monsters
			for (int i = 0; i < 15; i++) {
				MonsterCard x;
				try {
					x = (MonsterCard) ((MonsterCard) monsters.get((int) (Math.random()* monsters.size()))).clone();
					deck.add(x);
				} catch (CloneNotSupportedException e) {
					e.printStackTrace();
				}
				
			}	


			//adding 5 random spell cards
			for (int i = 0; i < 5; i++) {
				SpellCard s;
				try {
					s = (SpellCard)((SpellCard)spells.get((int)(Math.random()*spells.size()))).clone();
					deck.add(s);
				} catch (CloneNotSupportedException e) {
					e.printStackTrace();
				}
				
			}
			shuffleDeck();
		}



		public void shuffleDeck(){

			//		ArrayList<Card> A = new ArrayList<Card>();
			//		
			//		boolean[]shuffd = new boolean[20];
			//		Arrays.fill(shuffd, false);
			//		
			//		
			//		for (int i = 0; i < 20; ) {
			//			int rnd = (int) Math.random()*20;
			//			
			//			if(shuffd[rnd]==false){
			//				shuffd[rnd]=true;
			//				i++;
			//				A.add(deck.get(rnd));
			//			}
			//		}
			//		
			//		deck=A;


			Collections.shuffle(deck);


		}




		public ArrayList<Card> drawNCards(int n){
			ArrayList<Card> drawn = new ArrayList<Card>();

			for (int i = 0; i < n; i++) {
				drawn.add(deck.remove(0));
			}

			return drawn;
		}






		public Card drawOneCard(){
			Card x = deck.remove(0);
			return x;
		}




		public static String getMonstersPath() {
			return monstersPath;
		}




		public static void setMonstersPath(String monstersPath) {
			Deck.monstersPath = monstersPath;
		}




		public static String getSpellsPath() {
			return spellsPath;
		}




		public static void setSpellsPath(String spellsPath) {
			Deck.spellsPath = spellsPath;
		}




		public static ArrayList<Card> getMonsters() {
			return monsters;
		}




		public static void setMonsters(ArrayList<Card> monsters) {
			Deck.monsters = monsters;
		}




		public static ArrayList<Card> getSpells() {
			return spells;
		}




		public static void setSpells(ArrayList<Card> spells) {
			Deck.spells = spells;
		}




		public ArrayList<Card> getDeck() {
			return deck;
		}




		public void setDeck(ArrayList<Card> deck) {
			this.deck = deck;
		}




		
		

	}
