package eg.edu.guc.yugioh.board.player;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.management.RuntimeErrorException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import eg.edu.guc.yugioh.cards.Card;
import eg.edu.guc.yugioh.cards.Location;
import eg.edu.guc.yugioh.cards.Mode;
import eg.edu.guc.yugioh.cards.MonsterCard;
import eg.edu.guc.yugioh.cards.spells.SpellCard;
import eg.edu.guc.yugioh.exceptions.DefenseMonsterAttackException;
import eg.edu.guc.yugioh.exceptions.EmptyFieldException;
import eg.edu.guc.yugioh.exceptions.MissingFieldException;
import eg.edu.guc.yugioh.exceptions.MonsterMultipleAttackException;
import eg.edu.guc.yugioh.exceptions.MultipleMonsterAdditionException;
import eg.edu.guc.yugioh.exceptions.NoMonsterSpaceException;
import eg.edu.guc.yugioh.exceptions.NoSpellSpaceException;
import eg.edu.guc.yugioh.exceptions.UnexpectedFormatException;
import eg.edu.guc.yugioh.exceptions.UnknownCardTypeException;
import eg.edu.guc.yugioh.exceptions.UnknownSpellCardException;
import eg.edu.guc.yugioh.exceptions.WrongPhaseException;
import eg.edu.guc.yugioh.gui.ActiveField;
import eg.edu.guc.yugioh.gui.GUIBoard;
import eg.edu.guc.yugioh.gui.HoverableLabel;
import eg.edu.guc.yugioh.gui.Interface;
import eg.edu.guc.yugioh.gui.StartScreen;
import eg.edu.guc.yugioh.gui.TempoPanel;

public class Player implements Duelist{

	private String name;
	private int lifePoints;
	private Field field;
	private ArrayList<MonsterCard> Attacked = new ArrayList<MonsterCard>();
	private ArrayList<MonsterCard> Switched = new ArrayList<MonsterCard>();
	boolean summonedThisTurn=false;

	//	public static GUIBoard board;

	public Player(String name) throws CloneNotSupportedException, NumberFormatException, IOException, UnexpectedFormatException {
		this.name = name;
		setLifePoints(8000);
		field = new Field();
	}


	public String getName(){
		return name;
	}

	public Field getField(){
		return field;
	}


	public int getLifePoints() {
		return lifePoints;
	}


	public void setLifePoints(int lifePoints) {
		this.lifePoints = lifePoints;
	}


	public void deductPoints(int points){
		this.lifePoints-=points;
		Card.getBoard().checkGameStatus();
	}


	public static void WinWin(){
		JFrame Win = new JFrame();
		Win.setVisible(true);
		Win.setSize(new Dimension(300,300));
		Win.setTitle("Congratuations");
		
		Win.add(new JLabel("Congratulations " + Card.getBoard().getWinner().getName() + ", you have WON!!"), BorderLayout.NORTH);
		JButton x = new JButton("Restart");
		Win.add(x, BorderLayout.CENTER);
		x.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				new StartScreen();
			}
		});
	}


	public boolean someoneWon(){
		if(lifePoints<=0){
			Card.getBoard().setWinner(Card.getBoard().getOpponentPlayer());
			WinWin();
			return true;
		} else {
			if(Card.getBoard().getOpponentPlayer().getLifePoints()<=0){
				Card.getBoard().setWinner(this);
				WinWin();
				return true;
			}
		}
		return false;
	}


	public boolean gameOver(){
		if(someoneWon()) WinWin();
		return Card.getBoard().getWinner()!=null;
	}


	public boolean summonMonster(MonsterCard monster) {

		if(!field.getHand().contains(monster)){
			throw new RuntimeException("Not in your hand");
		}

		int x = getField().getMonstersArea().size();
		if(!gameOver()){
			if(field.getMonstersArea().size()<5){
				if(this.equals(Card.getBoard().getActivePlayer()) && monster.getLevel()<=4){
					if(summonedThisTurn==false){
						if(!((field.getPhase())==Phase.BATTLE)){
							summonedThisTurn=true;
							monster.setMode(Mode.ATTACK);
							monster.setHidden(false);
							monster.setLocation(Location.FIELD);

							field.getMonstersArea().add(monster);
							field.getHand().remove(monster);
							field.removeCardPicFromHand(monster);
							field.addMonsterPicToField(monster, true);
						} else {
							throw new WrongPhaseException();
						}
					}else {
						throw new MultipleMonsterAdditionException();
					}

					return x == getField().getMonstersArea().size() -1;
				}
			} else {
				throw new NoMonsterSpaceException();
			}
		}
		return false;
	}


	public boolean summonMonster(MonsterCard monster, ArrayList<MonsterCard> sacrifices){
		if(summonedThisTurn==false){
			int x = getField().getMonstersArea().size();
			if(x<5){
				if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()&&field.getHand().contains(monster)){
					if(!((field.getPhase())==Phase.BATTLE)){
						summonedThisTurn=true;
						getField().addMonsterToField(monster, Mode.ATTACK, sacrifices);
						field.removeCardPicFromHand(monster);
					} else {
						throw new WrongPhaseException();
					}
					return  getField().getMonstersArea().contains(monster);
				}
			} else {
				throw new NoMonsterSpaceException();
			}
		} else {
			throw new MultipleMonsterAdditionException();
		}
		return false;
	}


	public boolean setMonster(MonsterCard monster){
		if(field.getMonstersArea().size()<5){
			if(summonedThisTurn==false){
				if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()&&field.getHand().contains(monster)){
					if((field.getPhase())!=Phase.BATTLE){
						summonedThisTurn=true;
						getField().addMonsterToField(monster, Mode.DEFENSE, true);

						field.getHand().remove(monster);
						field.removeCardPicFromHand(monster);
						field.addMonsterPicToField(monster, false);
					} else {
						throw new WrongPhaseException();
					}
					return getField().getMonstersArea().contains(monster);
				}
			} else {
				throw new MultipleMonsterAdditionException();
			}
		} else {
			throw new NoMonsterSpaceException();
		}
		return false;
	}


	public boolean setMonster(MonsterCard monster, ArrayList<MonsterCard> sacrifices){
		if(field.getMonstersArea().size()<5){
			if(field.getPhase()!=Phase.BATTLE){
				if(summonedThisTurn==false){
					if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()&&field.getHand().contains(monster)&&(field.getPhase())!=Phase.BATTLE){
						summonedThisTurn=true;
						getField().addMonsterToField(monster, Mode.DEFENSE, sacrifices);
						field.removeCardPicFromHand(monster);
//						field.addMonsterPicToField(monster, false);
					}
					return getField().getMonstersArea().contains(monster);
				} else {
					throw new MultipleMonsterAdditionException();
				}
			} else {
				throw new WrongPhaseException();
			}
		} else {
			throw new NoMonsterSpaceException();
		}
		//		return false;	FIXME see why it says unreachable here but not in any of the above methods
	}


	public boolean setSpell(SpellCard spell) {
		int x = getField().getSpellArea().size();
		if(x<5){
			if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()&&field.getHand().contains(spell)){
				if(!((field.getPhase())==Phase.BATTLE)){
					getField().addSpellToField(spell, null, true);
				} else {
					throw new WrongPhaseException();
				}
				return field.getSpellArea().contains(spell);
			}
		} else {
			throw new NoSpellSpaceException();
		}
		return false;
	}


	public boolean activateSpell(SpellCard spell, MonsterCard monster){
		int x = getField().getGraveyard().size();
		if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()){
			if(!((field.getPhase())==Phase.BATTLE)){
				if(getField().getHand().contains(spell)){
					if(field.getSpellArea().size()<5){
						if(setSpell(spell)){
							getField().addSpellToField(spell, null, true);
							field.removeSpellPicFromField(spell);
							field.removeSpellPicFromField(spell);
//							Field.addCardPicToMyGraveyard(spell);
							spell.action(monster);
						}
					} else {
						throw new NoSpellSpaceException();
					}
				}
				else { 
					if(field.getSpellArea().contains(spell)){
						field.activateSetSpell(spell, monster);

					}
				}
			} else {
				throw new WrongPhaseException();
			}
			return field.getGraveyard().contains(spell);
		}
		return false;
	}



	public boolean declareAttack(MonsterCard activeMonster, MonsterCard opponentMonster){
		if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()){
			if(!Attacked.contains(activeMonster)){
				if(field.getPhase()==Phase.BATTLE){
					if(activeMonster.getMode() == Mode.ATTACK){
						Attacked.add(activeMonster);

						if(opponentMonster.getMode()==Mode.ATTACK){
							if(activeMonster.getAttackPoints()>opponentMonster.getAttackPoints()){
								Card.getBoard().getOpponentPlayer().deductPoints(activeMonster.getAttackPoints()-opponentMonster.getAttackPoints());	
								Card.getBoard().getOpponentPlayer().getField().removeMonsterToGraveyard(opponentMonster);
								//								field.removeMonsterPicFromField(opponentMonster);
							} else {
								if(activeMonster.getAttackPoints()==opponentMonster.getAttackPoints()){
									Card.getBoard().getOpponentPlayer().getField().removeMonsterToGraveyard(opponentMonster);
									Card.getBoard().getActivePlayer().getField().removeMonsterToGraveyard(activeMonster);
								}
								else{
									deductPoints(opponentMonster.getAttackPoints()-activeMonster.getAttackPoints());	
									getField().removeMonsterToGraveyard(activeMonster);
									//									field.removeMonsterPicFromField(activeMonster);
								}

							}
						} else {
							opponentMonster.setHidden(false);
							if(activeMonster.getAttackPoints()>opponentMonster.getDefensePoints()){	
								Card.getBoard().getOpponentPlayer().getField().removeMonsterToGraveyard(opponentMonster);
								//								field.removeMonsterPicFromField(opponentMonster);
							} else {
								if(activeMonster.getAttackPoints()==opponentMonster.getDefensePoints()){
								}
								else{
									deductPoints(opponentMonster.getDefensePoints()-activeMonster.getAttackPoints());
								}
							}
							field.changeHiddenToShownDef(opponentMonster);
						}
						someoneWon();
						TempoPanel.refresh();
						return true;
					} else {
						throw new DefenseMonsterAttackException();
					}
				} else{
					throw new WrongPhaseException();
				}
			} else {
				throw new MonsterMultipleAttackException();
			}
		}
		return false;
	}


	public boolean declareAttack(MonsterCard monster){
		if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()){
			if(Card.getBoard().getOpponentPlayer().getField().getMonstersArea().isEmpty()){
				if(!Attacked.contains(monster)){
					if(field.getPhase()==Phase.BATTLE){
						if(monster.getMode() == Mode.ATTACK){

							Attacked.add(monster);
							Card.getBoard().getOpponentPlayer().setLifePoints(Card.getBoard().getOpponentPlayer().getLifePoints()-monster.getAttackPoints());

							someoneWon();

							TempoPanel.refresh();
							return true;
						} else {
							throw new DefenseMonsterAttackException();
						}
					} else {
						throw new WrongPhaseException();
					}
				} else {
					throw new MonsterMultipleAttackException();
				}
			}
		}
		return false;
	}


	public void addCardToHand(){
		if(field.getDeck().getDeck().size()<1){
			Card.getBoard().setWinner(Card.getBoard().getOpponentPlayer());
			return;
		}
		if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()){
			if(!((field.getPhase())==Phase.BATTLE)){
				field.addCardToHand();
				TempoPanel.refresh();
			}
		}
	}


	public void addNCardsToHand(int n){
		if(field.getDeck().getDeck().size()<n){
			Card.getBoard().setWinner(Card.getBoard().getOpponentPlayer());
			return;
		}
		if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()){
			if(!((field.getPhase())==Phase.BATTLE)){
				field.addNCardsToHand(n);
				TempoPanel.refresh();
			}
		}
	}


	public void endPhase(){
		if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()){
			if(field.getPhase()==Phase.MAIN1){
				field.setPhase(Phase.BATTLE);
				TempoPanel.EndPhase.setText("Phase: Battle");
			} else {
				if(field.getPhase()==Phase.BATTLE){
					field.setPhase(Phase.MAIN2);
					TempoPanel.EndPhase.setText("Phase: Main2");
				} else {
					if(field.getPhase()==Phase.MAIN2){
						field.setPhase(Phase.MAIN1);
						endTurn();
					}
				}
			}
			Attacked.clear();
		}
	}


	public boolean endTurn(){

		//		if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()){
		Attacked.clear();
		Switched.clear();
		Card.getBoard().getOpponentPlayer().Switched.clear();
		summonedThisTurn=false;
		field.setPhase(Phase.MAIN1);
		TempoPanel.EndPhase.setText("Phase: Main1");
		GUIBoard.ChangeRefs();
		GUIBoard.hideHand();
		TempoPanel.refresh();
		Card.getBoard().nextPlayer();
		TempoPanel.EndTurn.setText(Card.getBoard().getActivePlayer().getName()+"\'s turn");
		return true;
		//		}

		//		return false;
	}


	public boolean switchMonsterMode(MonsterCard monster){
		if(field.getPhase()!=Phase.BATTLE){
			if(this.equals(Card.getBoard().getActivePlayer())&&!gameOver()&&field.getMonstersArea().contains(monster)){
				if(!Switched.contains(monster)){
					Switched.add(monster);
					Switch(monster);
					if(monster.isHidden())
						monster.setHidden(false);

					if(monster.getMode()==Mode.ATTACK){
						monster.setMode(Mode.DEFENSE);
						return true;
					} else {
						monster.setMode(Mode.ATTACK);
						return true;
					}

				}
			}
		} else {
			throw new WrongPhaseException();
		}
		return false;
	}


	public void Switch(MonsterCard monster) {
		for (int i = 0; i < ActiveField.getMonster().size(); i++) {
			HoverableLabel c = ActiveField.getMonster().get(i);
			if(monster == c.getX2()){
				if(monster.isHidden()){
					ImageIcon imageIcon = new ImageIcon(c.getX2().getPic());// load the image to a imageIcon
					Image image = imageIcon.getImage(); // transform it 
					Image newimg = image.getScaledInstance(80, 100,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
					imageIcon = new ImageIcon(newimg);  // transform it back
					c.setIcon(imageIcon);
				} else {
					ImageIcon imageIcon = new ImageIcon(c.getX2().getPic());// load the image to a imageIcon
					Image image = imageIcon.getImage(); // transform it 
					Image newimg = image.getScaledInstance(100, 80,  java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
					imageIcon = new ImageIcon(newimg);  // transform it back
					c.setIcon(imageIcon);
					// TODO, SWITCH THAT MOTHA. TO A ROTATED THING NOT A BACK OF A CARD
				}
			}
		}

	}



	//	public static void main(String[] args) throws CloneNotSupportedException, NumberFormatException, IOException {
	//		//		Board board = new Board();
	//		//		Player p1 = new Player("Yugi");
	//		//		Player p2 = new Player("Kaiba");
	//		//		board.startGame(p1, p2);
	//		//		MonsterCard vorseRaider = new MonsterCard("Vorse Raider",
	//		//				"A warrior beast", 4, 1900, 1200);
	//		//		MonsterCard geminiElf = new MonsterCard("Gemini Elf", "The Twins", 4,
	//		//				1900, 900);
	//		//
	//		//		board.getActivePlayer().getField().getMonstersArea().add(geminiElf);
	//		//		geminiElf.setLocation(Location.FIELD);
	//		//
	//		//		board.getActivePlayer().getField().getMonstersArea().add(vorseRaider);
	//		//		vorseRaider.setLocation(Location.FIELD);
	//		//
	//		//		MonsterCard darkMagician = new MonsterCard("Dark Magician",
	//		//				"uses dark magic", 8, 2500, 2100);
	//		//
	//		//		board.getActivePlayer().getField().getHand().add(darkMagician);
	//		//		darkMagician.setLocation(Location.HAND);
	//		//
	//		//		ArrayList<MonsterCard> l = new ArrayList<MonsterCard>();
	//		//		l.add(vorseRaider);
	//		//		l.add(geminiElf);
	//		//		for (int i = 0; i < l.size(); i++) {
	//		//
	//		//			System.out.println(l.get(i).getName());	
	//		//		}
	//		//		
	//		//		board.getActivePlayer().summonMonster(darkMagician, l);
	//		//
	//		//		
	//
	//
	//		Board board = new Board();
	//		Player p1 = new Player("Yugi");
	//		Player p2 = new Player("Kaiba");
	//		board.startGame(p1, p2);
	//
	//		MonsterCard vorseRaider = new MonsterCard("Vorse Raider",
	//				"A warrior beast", 4, 1900, 1200);
	//
	//		vorseRaider.setLocation(Location.HAND);
	//		board.getActivePlayer().getField().getHand().add(vorseRaider);
	//
	//		board.getActivePlayer().setMonster(vorseRaider);
	//
	//		System.out.println(board.getActivePlayer().getField().getMonstersArea().get(0));
	//
	//
	//
	//
	//
	//	}

}
