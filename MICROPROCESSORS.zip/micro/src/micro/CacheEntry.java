package micro;

public class CacheEntry implements Comparable{

	String tag,index,offset,sokrat,heba;
	
	public String getHeba() {
		return heba;
	}

	public void setHeba(String heba) {
		this.heba = heba;
	}

	public String getSokrat() {
		return sokrat;
	}

	public void setSokrat(String sokrat) {
		this.sokrat = sokrat;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public String getOffset() {
		return offset;
	}

	public void setOffset(String offset) {
		this.offset = offset;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	String data ; 
	Memory mem;
	
	public CacheEntry(int Address,String Data,int OffSetBits,int IndexBits, Memory mem){
		this.mem = mem;
		data = Data;
		offset = "";
		tag = "";
		index = "";
		constructEntryIndex(Address, OffSetBits+2, IndexBits);
	}
	
	public void constructEntryIndex(int Ad, int OffSetBits, int IndexBits){
		String Address = Integer.toString(0x10000 | Ad, 2).substring(1);
		
		offset = Address.substring(Address.length()-OffSetBits);
		index = Address.substring(Address.length()-OffSetBits-IndexBits, Address.length()-OffSetBits);
		tag = Address.substring(0, Address.length()-OffSetBits-IndexBits);
		
		offset = ""+Integer.parseInt(offset, 2);
		index = ""+Integer.parseInt(index, 2);
		tag = ""+Integer.parseInt(tag, 2);
	}
	
	public int compareTo(Object o){
		CacheEntry ce = (CacheEntry) o;
		
		return (ce.index.equals(this.index) && ce.tag.equals(this.tag))?1:0;
	}
	
	public Instruction getInInstructionForm(){
		//CacheEntry data contains the instruction in String format
		String [] fragments = data.split(",");
		
		Instruction in;
		//HERE WE RECONSTRUCT IT AS INSTRUCTION AGAIN
		if(fragments.length == 2){
			in = new Instruction(fragments[0], Integer.parseInt(fragments[1]), 0, 0, mem);
		} else{
			if(fragments.length == 3){
				in = new Instruction(fragments[0], Integer.parseInt(fragments[1]), Integer.parseInt(fragments[2]), 0, mem);
			} else {
				in = new Instruction(fragments[0], Integer.parseInt(fragments[1]), Integer.parseInt(fragments[2]), Integer.parseInt(fragments[3]), mem);
			}
		}
		
		// RETURN IT FOR LATER USE IN PROCESSOR
		return in;
	}

}
