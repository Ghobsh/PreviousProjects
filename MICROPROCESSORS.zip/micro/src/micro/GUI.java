package micro;

import javax.swing.JFrame;

public class GUI {

	public GUI() {
		// TODO Auto-generated constructor stub
		
		Landing landing= new Landing();
		landing.setVisible(true);
		
	}
	public static void main(String[] args) {
		GUI x = new GUI();
	}

}
