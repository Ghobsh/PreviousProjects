package micro;

public class Instruction {

	Memory mem;

	String InstructionType;
	String InstructionName;

	int Operand1;
	int Operand2;
	int Operand3;

	
	
	public void setMem(Memory mem){
		this.mem = mem;
	}

	public Instruction(String Name, int OP1, int OP2, int OP3, Memory mem){
		this.mem = mem;
		switch (Name){
		//XXX INSTRUCTIONS THAT TAKE 3 OPERANDS, 
		//INCLUDE: ARITHMETICS, LOAD/STORE, CONDITIONAL BRANCHES
		case "LW":
		case "SW":
		case "BEQ":
		case "ADD":
		case "SUB":
		case "ADDI":
		case "NAND":
		case "MUL": {
			InstructionType = "Defined";
			InstructionName = Name;
			Operand1 = OP1;
			Operand2 = OP2;
			Operand3 = OP3;
			break;
		}

		//XXX INSTRUCTIONS THAT TAKE 2 OPERANDS, 
		//INCLUDE: JMP, JALR, 
		case "JMP":
		case "JALR": {
			InstructionType = "Defined";
			InstructionName = Name;
			Operand1 = OP1;
			Operand2 = OP2;
			break;
		}

		//XXX INSTRUCTIONS THAT TAKE 1 OPERAND, 
		//INCLUDE: RET
		case "RET": {
			InstructionType = "Defined";
			InstructionName = Name;
			Operand1 = OP1;
			break;
		}
		default: InstructionType = "Undefined";
		}
	}

	public void ActivateInstruction(){
		if(InstructionType.equals("Undefined")) return; //XXX FAILSAFE FROM STUPID PEOPLE.

		switch (InstructionName){
		case "LW": Load(); break;
		case "SW": Store(); break;
		case "BEQ": Branch(); break;
		case "ADD": Add(); break;
		case "SUB": Subtract(); break;
		case "ADDI": Addi(); break;
		case "NAND": Nand(); break;
		case "MUL": Mul(); break;
		case "JMP": Jump(); break;
		case "JALR": JALR(); break;
		case "RET": Return(); break;
		}
	}

	public void Load(){
		int Target = mem.getProcessor().RegFile[Operand2] + Operand3;
		mem.getProcessor().RegFile[Operand1] = Integer.parseInt(mem.getFromMemoryAddress(Target));
	}

	public void Store(){
		int Target = mem.getProcessor().RegFile[Operand2] + Operand3;
		mem.storeToMemoryAddress(mem.getProcessor().RegFile[Operand1], Target);
	}

	public void Branch(){
		if(mem.getProcessor().RegFile[Operand1] == mem.getProcessor().RegFile[Operand2]) mem.JumpTo(Operand3 +1);
	}

	public void JALR(){
		mem.getProcessor().RegFile[Operand1]= mem.getPc();
		mem.JumpTo(mem.getProcessor().RegFile[Operand2]);
		//pc
	}
	
	public void Return(){
		mem.JumpTo(mem.getProcessor().RegFile[Operand1]);

	}

	public void Jump(){
		mem.JumpTo(Operand2 +1+mem.getProcessor().RegFile[Operand1]);
	}

	public void Add(){
		mem.getProcessor().RegFile[Operand1] = mem.getProcessor().RegFile[Operand2] + mem.getProcessor().RegFile[Operand3];
	}

	public void Subtract(){
		mem.getProcessor().RegFile[Operand1] = mem.getProcessor().RegFile[Operand2] - mem.getProcessor().RegFile[Operand3];
	}

	public void Addi(){
		mem.getProcessor().RegFile[Operand1] = mem.getProcessor().RegFile[Operand2] + Operand3;
	}

	public void Mul(){
		mem.getProcessor().RegFile[Operand1] = mem.getProcessor().RegFile[Operand2] * mem.getProcessor().RegFile[Operand3];
	}

	public void Nand(){
		mem.getProcessor().RegFile[Operand1] = ~(mem.getProcessor().RegFile[Operand2] & mem.getProcessor().RegFile[Operand3]);
	}
	
	public String toString(){ //EX. ADD,R1,R2,R3
		return InstructionName+","+Operand1+","+Operand2+","+Operand3;
	}

}
