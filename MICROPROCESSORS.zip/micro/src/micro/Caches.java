package micro;

import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.BoxLayout;
import javax.swing.JButton;

public class Caches extends JFrame {

//	private JFrame frame;
	boolean moveOn= true;
	BoxLayout box;
	static Container[] containers= new Container[Landing.noOfCaches]; 
	static String[] S=new String[Landing.noOfCaches];
	static String[] L=new String[Landing.noOfCaches];
	static String[] M=new String[Landing.noOfCaches];
	static String[] policy=new String[Landing.noOfCaches];
	static String[] accessCycles=new String[Landing.noOfCaches];
	
	



	

	/**
	 * Create the application.
	 */
	public Caches() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
//		this = new JFrame();
		this.setBounds(50, 50, 750, 500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 box=new BoxLayout(getContentPane(), BoxLayout.Y_AXIS);
		getContentPane().setLayout(box);
	
		for(int i = 0; i< Landing.noOfCaches;i++){
			Container container=new CacheLayout();
			this.getContentPane().add(container);
			containers[i]=(Container) container;
			
		}
		
		Container btn= new Container();
		
		btn.setLayout(new FlowLayout(FlowLayout.CENTER));
		JButton create = new JButton("Create");
		create.setBounds(190, 164, 89, 23);
		btn.add(create);
		getContentPane().add(btn);
		
		create.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				moveOn=true;
				for (int j = 0; j < Landing.noOfCaches; j++) {
					CacheLayout cont= (CacheLayout) containers[j];
					S[j]=cont.getS();
					M[j]= cont.getM();
					L[j]= cont.getL();
					policy[j]= cont.getPolicy();
					accessCycles[j]= cont.getAccessCycles();
					if(!S[j].equals("")&&!M[j].equals("")&&!L[j].equals("")&&!policy[j].equals("")&&!accessCycles[j].equals("")&&moveOn){
										moveOn=true;
					}
					else 
						moveOn=false;
					

					
				}
//				S.length>1&&M.length>1&&L.length>1&&policy.length>1&&accessCycles.length>1&&
				if(moveOn){
				close();
				Excute excute = new Excute();
				}
				else{
					 Component frame = new JFrame();
			        JOptionPane.showMessageDialog(frame,
			        		"Fill all the fields",
			        		"error",
			        	    JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		
		
	}
	
	public void close(){
		this.dispose();
	}
	
	
}
