package micro;

public class CacheFile {
	
	Cache[] cacheLevels;
	int[] cacheCost;
	boolean[] cacheHit;
	int[][]cacheHitRate;
	
	Memory memory;
	
	int lastSearchCost = 0;
	
	public CacheFile(int noOfLevels, Memory memory){
		cacheLevels = new Cache[noOfLevels];
		cacheCost = new int[noOfLevels];
		cacheHit = new boolean[noOfLevels];
		cacheHitRate = new int[noOfLevels][2];
		this.memory = memory;
	}
	
	public void makeCache(int sizeOfCache, int LineSize, int AssociativityLevels, String writePolicy, int cacheLevel, int noOfCyclesToAccessData){
		cacheLevels[cacheLevel] = new Cache(sizeOfCache, LineSize, AssociativityLevels, writePolicy, cacheLevel, noOfCyclesToAccessData, memory);
		cacheCost[cacheLevel] = noOfCyclesToAccessData;
	}
	
	public CacheEntry searchCache (int Add){
		
		for (int i = 0; i < cacheLevels.length; i++) { //ALTHOUGH CACHE LEVELS START FROM LEVEL 1, HENA OUR INDEX IS ZERO.
			
			CacheEntry Data = cacheLevels[i].searchCache(Add); //SEARCHING EACH CACHE LEVELS FOR THE SHIT YOU WANT.
			lastSearchCost += cacheLevels[i].getNoOfCyclesToAccessData();
			
			cacheHitRate[i][1]++;
			
			if(Data != null) { //MEANS WE FOUND IT
				cacheHitRate[i][0]++;
				cacheHit[i] = true;
				return Data;
			} else {
				cacheHit[i] = false;
			}
		}
		
		return null; //NOT IN CACHES KHALES
	}
	
	public boolean insertIntoCache (int Address, String Data){
		
		for (int i = 0; i < cacheLevels.length; i++) {
			cacheLevels[i].insertIntoCache(Address, Data);
		}
		
		return true;
	}

	public void updateCacheEntry(Object Data, int Address){
		for (int i = 0; i < cacheLevels.length; i++) { //ALTHOUGH CACHE LEVELS START FROM LEVEL 1, HENA OUR INDEX IS ZERO.
			
			CacheEntry yahya = cacheLevels[i].searchCache(Address); //SEARCHING EACH CACHE LEVELS FOR THE SHIT YOU WANT.
			
			yahya.setData((String)Data);
		}
	}

	public int[][] getCacheHitRates(){
		return cacheHitRate;
	}
	
	public void printAfterIteration(){
		for (int i = 0; i < cacheLevels.length; i++) {
			cacheLevels[i].printCacheContents();
		}
	}
}
