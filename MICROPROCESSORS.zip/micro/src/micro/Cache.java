package micro;

import java.util.ArrayList;
import java.util.Hashtable;

//import com.sun.javafx.css.CascadingStyle;

public class Cache {

	Memory memory; //TODO REMEMBER TO SET MEMORY WHEN CREATING NEW INSTANCES OF CACHE
	
	CacheEntry[][] cache;
	int[] MRU;
	
	int sizeOfCache, LineSize, AssociativityLevels, cacheLevel, noOfCyclesToAccessData;
	String writePolicy;
	
	int cacheSize;
	
	public Cache(int sizeOfCache , int LineSize ,int AssociativityLevels, String writePolicy, int cacheLevel ,int noOfCyclesToAccessData, Memory memory){
		
		//Save inputs to use later
		this.memory = memory;
		this.sizeOfCache = sizeOfCache;
		this.LineSize = LineSize;
		this.AssociativityLevels = AssociativityLevels;
		this.writePolicy = writePolicy;
		this.cacheLevel = cacheLevel;
		this.noOfCyclesToAccessData = noOfCyclesToAccessData;
		
		
		//Calculate the table size of cache
		cacheSize = sizeOfCache/LineSize;
		
		//Instantiate cache table
		cache = new CacheEntry[cacheSize][LineSize];
		MRU = new int[cacheSize/AssociativityLevels]; //(TOTAL SIZE / SET SIZE), EVERY ONE CELL POINTS TO A SET'S MOST RECENTLY USED IN ORDER TO REPLACE THAT
	}
	
	
	//XXX INSERT INTO CACHE LOGIC
	////////////////////////////////////////////////////////////
	public boolean insertIntoCache(int Address, String Data){
		
		int indexBits = (int) (Math.log10(cacheSize)/Math.log10(2));
		int offSetBits = (int) (Math.log10(LineSize)/Math.log10(2));
		
		CacheEntry word = new CacheEntry(Address, Data, offSetBits, indexBits, memory);
		
		//SEARCH WHERE TO PUT THIS LINE IN A CACHE
		//THE THIRD PARAMETER IS TO UPDATE THE MRU TABLE WITH THE APPROPRIATE INDEX TO THE SET INDEX OF THE MOST RECENTLY USED ENTRY OF THE SET.
		int indexToBePlacedIn = getMostRecentlyUsedIndex(Integer.parseInt(word.getIndex()));
		
		//CALL THIS TO PUT ALL CACHE LINE IN CACHE, WE DON'T DEAL WITH WORDS ONLY
		return insertLineIntoCache(Address, indexToBePlacedIn, Integer.parseInt(word.getIndex()));
		
	}
	
	
	public boolean insertLineIntoCache(int Address, int indexToBePlacedIn, int indexForMRU){
		int startingAddress = Address - (Address % LineSize);
		
		for (int i = 0; i < LineSize; i++) {
			String Data = memory.getFromMemoryAddressNoCache(startingAddress+i);
			CacheEntry Entry = new CacheEntry(startingAddress+i, Data, (int) (Math.log10(LineSize)/Math.log10(2)), (int) (Math.log10(cacheSize)/Math.log10(2)), memory);
			cache[indexToBePlacedIn][i] = Entry;
		}
		
		MRU[indexForMRU] = indexToBePlacedIn;
		
		return true;
	}
	
	
	public int getMostRecentlyUsedIndex(int index){
		
		for (int i = 0; i < AssociativityLevels; i++) {
			if(cache[index*AssociativityLevels + i] == null){
				return index*AssociativityLevels + i;
			}
		}
		
		return index*AssociativityLevels + MRU[index];
	}
	////////////////////////////////////////////////////////////
	
	//XXX SEARCH CACHE LOGIC
	////////////////////////////////////////////////////////////
	public CacheEntry searchCache(int Add){
		String Address = Integer.toString(0x10000 | Add, 2).substring(1);
		System.out.println("DEBUG: adressthatcachesearchesfor" + Address);
		int OffSetBits = (int) (Math.log10(LineSize)/Math.log10(2))+2;
		int IndexBits = (int) (Math.log10(cacheSize)/Math.log10(2));
		
		// HERE WE CALCULATE THE ADDRESS SUPPOSED INDEX TAG AND OFFSET
		int offset = Integer.parseInt(Integer.parseInt(Address.substring(Address.length()-OffSetBits))+"",2);
		int index = Integer.parseInt(Integer.parseInt(Address.substring(Address.length()-OffSetBits-IndexBits, Address.length()-OffSetBits))+"", 2);
		int tag = Integer.parseInt(Integer.parseInt(Address.substring(0, Address.length()-OffSetBits-IndexBits))+"", 2);
		
		
		
		//BEFORE GOING IN, WE KNOW THAT INDICIES ARE EQUAL
		System.out.println("DEBUG: CACHE LENGTH"+cache.length);
		System.out.println("DEBUG: CACHE ENTRY"+cache[index][0]);
		if(cache[index][0]!=null && Integer.parseInt(cache[index][0].tag) == tag){ //SO HERE WE CHECK FOR TAGS
			for (int i = 0; i < cache[index].length; i++) { //HERE WE LOOK FOR THE SPECIFIC CACHE ENTRY THAT WE WANT, USING OFFSET
				if(Integer.parseInt(cache[index][i].offset) == offset){
					return cache[index][i];
				}
			}
		} else {
			return null;
		}
		
		return null;
	}

	public int getNoOfCyclesToAccessData() {
		return noOfCyclesToAccessData;
	}


	public void setNoOfCyclesToAccessData(int noOfCyclesToAccessData) {
		this.noOfCyclesToAccessData = noOfCyclesToAccessData;
	}

	public void printCacheContents(){
		
		System.out.println("OFFSET----------------------INDEX----------------------------TAG-----------------------------DATA");
		
		for (int i = 0; i < cache.length; i++) {
			for (int j = 0; j < cache[i].length; j++) {
				if(cache[i][j] != null)
				System.out.println(cache[i][j].getOffset()+"----------------------"+cache[i][j].getIndex()+"----------------------------"+cache[i][j].getTag()+"-----------------------------"+cache[i][j].getData());
			}
		}
	}
	
}













////checking word location in cache for availability
//if(cache[Integer.parseInt(word.getIndex())].compareTo(word) == 0){ //MEANS THAT THEY'RE THE SAME, OR IMPORTED AT SOME POINT WITH ANOTHER THING
//	return true;
//} else {
//	//MEANS THAT THEY'RE NOT THE SAME, WE SHOULD NOW PLACE AT THE CORRECT ENTRY
//}