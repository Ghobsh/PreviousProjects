package micro;

public class CacheLine {
	
	CacheEntry [] Line;
	
	public CacheLine(int size){
		Line = new CacheEntry[size];
	}

}
