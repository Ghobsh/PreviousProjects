package micro;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Processor {

	Memory memory;
	CacheFile dataCache;
	CacheFile instructionCache;
	int InstructionRate,InstructionHit ,InstrucionMiss =0;
	int[] RegFile = {0, 0, 0, 0, 0, 0, 0, 0};
	
	public Processor(String[][] dataCacheLevelInput, String[][] instructionCacheLevelInput, String[] CODE,
			String startingPC, ArrayList<String> memoryChanges) {

		memory = new Memory(130);
		//DI EL FOOLA BA2A XD, HERE WE SET THE PROCESSOR TO THE MEMORY SO IT CAN USE THE DATA CACHE FILE AS WELL, NO IDEA WHY WE DIDN'T PUT THE DATA CACHE IN MEMORY IN THE FIRST PLACE
		memory.setProcessor(this);
		
		dataCache = new CacheFile(dataCacheLevelInput.length, memory);
		instructionCache = new CacheFile(instructionCacheLevelInput.length, memory);
		
		//creating data cache using input from user
		for (int i = 0; i < dataCacheLevelInput.length; i++) {
			
			int size = Integer.parseInt(dataCacheLevelInput[i][0]) ;
			int l = Integer.parseInt(dataCacheLevelInput[i][1]) ;
			int m = Integer.parseInt(dataCacheLevelInput[i][2]) ;
			String wrtingpolicy = dataCacheLevelInput[i][3] ;
			int noc = Integer.parseInt(dataCacheLevelInput[i][4]) ;

			dataCache.makeCache(size, l, m, wrtingpolicy, i, noc);
		}
		
		// creating instruction cache
		for (int i = 0; i < instructionCacheLevelInput.length; i++) {
		
			int size = Integer.parseInt(instructionCacheLevelInput[i][0]) ;
			int l = Integer.parseInt(instructionCacheLevelInput[i][1]) ;
			int m = Integer.parseInt(instructionCacheLevelInput[i][2]) ;
			String wrtingpolicy = instructionCacheLevelInput[i][3] ;
			int noc = Integer.parseInt(instructionCacheLevelInput[i][4]) ;

			instructionCache.makeCache(size, l, m, wrtingpolicy, i, noc);
		}
		
		
		//SETTING THE INITIAL pc position
		int PC = Integer.parseInt(startingPC);
		memory.setPC(PC);
		
		
		//ADDING INITIAL MEMORY CHANGES AS PER USER INPUT
		for (int i = 0; i < memoryChanges.size(); i++) {
			
			String change = memoryChanges.get(i);
			
			String [] changePair = change.split(",");
			
			int Address = Integer.parseInt(changePair[0]);
			
			memory.storeToMemoryAddress(changePair[1], Address);
		}
		
		//LAST BUT DEFINATELY NOT LEAST
		//MAKING THE INSRTUCTION ARRAY AND STORING IT INTO MEMORY
		for (int i = 0; i < CODE.length; i++) {
			String [] fragments = CODE[i].split(",");
			
			Instruction in;
			if(fragments.length == 2){
				in = new Instruction(fragments[0], Integer.parseInt(fragments[1]), 0, 0, memory);
			} else{
				if(fragments.length == 3){
					in = new Instruction(fragments[0], Integer.parseInt(fragments[1]), Integer.parseInt(fragments[2]), 0, memory);
				} else {
					in = new Instruction(fragments[0], Integer.parseInt(fragments[1]), Integer.parseInt(fragments[2]), Integer.parseInt(fragments[3]), memory);
				}
			}
			
			memory.storeInstructionToMemoryAddress(in, PC+i);
		}
		
		
		
		beginProcessing(CODE.length);
	}
	
	public void beginProcessing(int numberOfInstructions){
		for (int i = 0; i < numberOfInstructions; i++) {
			
			//USING MEMORY CURRENT PC, WE SEARCH FOR THE INSTRUCTION IN THE MEMORY CACHE
			CacheEntry instructionFromCache = instructionCache.searchCache(memory.getPc());
			InstructionRate++;
			if(instructionFromCache == null){ // MEANS WE HAVEN'T FOUND IT
				Object memoryLine = memory.getNextInstruction();
				InstrucionMiss++;
				if(memoryLine instanceof Instruction){ //IF IT IS AN INSTRUCTION ASLAN NOT A TYPO
					Instruction ghobashy = (Instruction) memoryLine;
					ghobashy.ActivateInstruction();
					
					instructionCache.insertIntoCache(memory.getPc()-1, ghobashy.toString());
				} else {
					System.out.println("END OF RUNNABLE PROGRAM");
				}
			} else {
				InstructionHit++;
				Instruction ghobashy = (Instruction) instructionFromCache.getInInstructionForm();
				ghobashy.ActivateInstruction();
				memory.setPC(memory.getPc()+1);
				
				instructionCache.insertIntoCache(memory.getPc()-1, ghobashy.toString());
			}
			
			System.out.println("INSTRUCTION CACHE CONTENT THIS ITERATION:");
			instructionCache.printAfterIteration();
			
			System.out.println("DATA CACHE CONTENT THIS ITERATION:");
			dataCache.printAfterIteration();
		}
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		
		//FIRST: USER INPUT FOR CACHES

		//HERE WE TAKE USER INPUT ABOUT DATA CACHE
		System.out.println("PLEASE ENTER: NUMBER OF DESIRED DATA CACHE LEVELS");
		int dataCacheLevels = Integer.parseInt(br.readLine());
		
		String[][] dataCacheLevelInput = new String[dataCacheLevels][5]; //TODO TAKE THIS INTO PROCESSOR CONSTRUCTOR
		for (int i = 0; i < dataCacheLevels; i++) {
			
			System.out.println("PLEASE ENTER: CACHE (SIZE)");
			String cacheSize = br.readLine();

			System.out.println("PLEASE ENTER: CACHE (LINEWIDTH)");
			String lineWidth = br.readLine();

			System.out.println("PLEASE ENTER: CACHE (ASSOCIATIVITY)");
			String M = br.readLine();
			
			System.out.println("PLEASE ENTER: CACHE (WRITING POLICIES)");
			String policy = br.readLine();
			
			System.out.println("PLEASE ENTER: CACHE (ACCESS TIME)");
			String at = br.readLine();
			
			dataCacheLevelInput[i][0] = cacheSize;
			dataCacheLevelInput[i][1] = lineWidth;
			dataCacheLevelInput[i][2] = M;
			dataCacheLevelInput[i][3] = policy;
			dataCacheLevelInput[i][4] = at;
		}

		System.out.println("=================================================================================================");
		
		//HERE WE TAKE USER INPUT ABOUT INSTRUCTION CACHE
		System.out.println("PLEASE ENTER: NUMBER OF DESIRED INSTRUCTION CACHE LEVELS");
		int instructionCacheLevels = Integer.parseInt(br.readLine());
		
		String[][] instructionCacheLevelInput = new String[instructionCacheLevels][5]; //TODO TAKE THIS INTO PROCESSOR CONSTRUCTOR
		for (int i = 0; i < instructionCacheLevels; i++) {
			
			System.out.println("PLEASE ENTER: CACHE (SIZE)");
			String cacheSize = br.readLine();

			System.out.println("PLEASE ENTER: CACHE (LINEWIDTH)");
			String lineWidth = br.readLine();

			System.out.println("PLEASE ENTER: CACHE (ASSOCIATIVITY)");
			String M = br.readLine();
			
			System.out.println("PLEASE ENTER: CACHE (WRITING POLICIES)");
			String policy = br.readLine();
			
			System.out.println("PLEASE ENTER: CACHE (ACCESS TIME)");
			String at = br.readLine();
			
			instructionCacheLevelInput[i][0] = cacheSize;
			instructionCacheLevelInput[i][1] = lineWidth;
			instructionCacheLevelInput[i][2] = M;
			instructionCacheLevelInput[i][3] = policy;
			instructionCacheLevelInput[i][4] = at;
		}

		System.out.println("=================================================================================================");
		
		// TAKE CODE AS INPUT
		System.out.println("PLEASE ENTER: CODE (SIZE OF PROGRAM)");
		int codeSize = Integer.parseInt(br.readLine());
		
		String[] CODE = new String[codeSize]; //TODO TAKE THIS INTO PROCESSOR CONSTRUCTOR
		for (int i = 0; i < CODE.length; i++) {
			
			System.out.println("PLEASE ENTER: CODE (LINE " + i + ")");
			System.out.println("MAKE SURE THAT THE FORMAT IS \"INSTRUCTION\" \"COMMA\" \"OPERAND1\" \"COMMA\" \"OPERAND2\" \"COMMA\" \"OPERAND3\"");
			System.out.println("EXAMPLE: \"AddI,1,2,3\"");
			
			String codeLine = br.readLine();
			
			CODE[i] = codeLine;
		}

		System.out.println("=================================================================================================");
		
		// TAKE PC AS INPUT TO STORE THE INSTRUCTIONS IN
		System.out.println("PLEASE ENTER: PROCESSOR (STARTING PC)");
		String startingPC = br.readLine(); //TODO TAKE THIS INTO PROCESSOR CONSTRUCTOR

		System.out.println("=================================================================================================");
		
		// TAKE INITIAL DATA AND PUT IT INTO MEMORY
		System.out.println("PLEASE ENTER: MEMORY (INITIAL MEMORY DATA CHANGES)");
		System.out.println("MAKE SURE TO ENTER THEM AS A PAIR OF (ADDRESS, DATA)");
		System.out.println("WHEN YOU ARE DONE EDITING, PLEASE TYPE \"FINISH\" (WITHOUT PARANTHESIS)");
		
		int i = 0;
		ArrayList<String> memoryChanges = new ArrayList<String>(); //TODO TAKE THIS INTO PROCESSOR CONSTRUCTOR
		while(true){
			String changeLinePair = br.readLine();
			
			if(changeLinePair.equalsIgnoreCase("FINISH")){
				break;
			}
			
			memoryChanges.add(changeLinePair);
		}
		
		//CONSTRUCTING THE PROCESSOR
		Processor processor = new Processor(dataCacheLevelInput, instructionCacheLevelInput, CODE, startingPC, memoryChanges);
		
		//CONSTRUCTOR AUTOMATICALLY TRIGGERS PROCESSING
		//THE LINES THAT FOLLOW WILL BE EXECUTED (IN THEORY) AFTER ALL PROCESSING HAS BEEN DONE
		System.out.println("-------------------------------------------------------------------------------------------------");
		System.out.println("DATA CACHE HIT RATE: " + processor.memory.DataHit/(processor.memory.DataRate+1));
		System.out.println("INSTRUCTION CACHE HIT RATE: " + processor.InstructionHit/(processor.InstructionRate+1));
		
		System.out.println("-------------------------------------------------------------------------------------------------");
		int[][] dataCachePerformance = processor.dataCache.getCacheHitRates();
		for (int j = 0; j < dataCachePerformance.length; j++) {
			System.out.println("DATA CACHE LEVEL " + j + "HIT RATE: " + dataCachePerformance[j][0]/(dataCachePerformance[j][1]+1));
		}
		
		System.out.println("-------------------------------------------------------------------------------------------------");
		int[][] instructionCachePerformance = processor.instructionCache.getCacheHitRates();
		for (int j = 0; j < dataCachePerformance.length; j++) {
			System.out.println("DATA CACHE LEVEL " + j + "HIT RATE: " + instructionCachePerformance[j][0]/(instructionCachePerformance[j][1]+1));
		}
		
		System.out.println("-------------------------------------------------------------------------------------------------");
		System.out.println("FINAL REGISTER FILE CONTENTS: ");
		for (int j = 0; j <processor.RegFile.length; j++) {
			System.out.println("R"+j+": "+ processor.RegFile[j]);
		}
	}
	
}
