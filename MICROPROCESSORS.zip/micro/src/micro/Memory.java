package micro;

import java.util.HashMap;

public class Memory {

	final int MEM_SIZE = 64000;
	int PC, accessTime = 0;
	int DataRate,DataHit, Datamiss=0;

	Processor processor;


	public void setPC(int pC) {
		PC = pC;
	}

	Object[] MEM;

	public Memory(int accessTime){
		this.accessTime = accessTime;
		MEM = new Object[MEM_SIZE];
	}

	//INSTRUCTION MEMORY SECTION
	public int getPc(){
		return PC;
	}

	public Object getNextInstruction(){
		PC++;
		return MEM[PC-1];
	}
	
	public void JumpTo(int InstructionAddress){
		PC = InstructionAddress;
	}
	
	//DATA MEMORY SECTION
	public String getFromMemoryAddress(int Address){
		//FIRST WE SEARCH IN THE CACHE, IF FOUND WE USE IT AS IS
		CacheEntry hossam = processor.dataCache.searchCache(Address);
		DataRate++;
		if(hossam != null){
			DataHit++;
			return hossam.data;
		} else { //SECOND ELSE SEARCH IN MEMORY THEN INSERT IN DATA CACHE
			Datamiss++;
			processor.dataCache.insertIntoCache(Address, (String) MEM[Address]);
			return (String) MEM[Address];
		}
	}
	
	public String getFromMemoryAddressNoCache(int Address){
		if(MEM[Address]!=null&&MEM[Address]instanceof Instruction) return MEM[Address].toString();
		return (String) MEM[Address];
	}
	
	public void storeToMemoryAddress(Object o, int Address){
		processor.dataCache.updateCacheEntry(o, Address);
		MEM[Address] = o;
	}
	
	public void storeInstructionToMemoryAddress(Object o, int Address){
		MEM[Address] = o;
	}

	public Processor getProcessor() {
		return processor;
	}

	public void setProcessor(Processor processor) {
		this.processor = processor;
	}
}
