package micro;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

public class Landing extends JFrame {
	private JTextField textField;
	static int noOfCaches;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public Landing() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblNumberOfCaches = new JLabel("Number of caches");
		lblNumberOfCaches.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNumberOfCaches.setBounds(10, 101, 208, 52);
		getContentPane().add(lblNumberOfCaches);
		
		textField = new JTextField();
		textField.setBounds(250, 123, 86, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnOk = new JButton("OK");
		btnOk.setBounds(190, 164, 89, 23);
		getContentPane().add(btnOk);
		btnOk.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				noOfCaches= Integer.parseInt(textField.getText());
				if(noOfCaches>0&&noOfCaches<4){
				close();
				Caches caches = new Caches();
				caches.setVisible(true);
				}
				else{
					
			        Component frame = new JFrame();
			        JOptionPane.showMessageDialog(frame,
			        		"Must be greater than Zero and greater than 3",
			        		"error",
			        	    JOptionPane.ERROR_MESSAGE);
//			        JOptionPane.showMessageDialog(frame , "Must be greater than Zero and less than 3", -1);
//					JOptionPane alert= new JOptionPane();
////					alert.show();
////					alert.show(true);
//					alert.setVisible(true);
				}
			}
		});
	}
	public void close(){
		this.dispose();
	}
}
