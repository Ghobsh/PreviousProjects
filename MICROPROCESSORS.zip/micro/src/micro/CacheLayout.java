package micro;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class CacheLayout extends Container{
			static JTextField S;
			static JTextField L;
			static JTextField M;
			static JTextField accessCycles;
			JRadioButton rdbtnWriteBack;
			JRadioButton rdbtnWriteThrough;
			static String policy;
			
			
			
	public static String getPolicy() {
				return policy;
			}

			public static void setPolicy(String policy) {
				CacheLayout.policy = policy;
			}

	public CacheLayout(){
		
		
		this.setLayout(null);
		S = new JTextField();
		S.setBounds(32, 29, 86, 20);
		this.add(S);
		S.setColumns(10);
		
		L = new JTextField();
		L.setColumns(10);
		L.setBounds(186, 29, 86, 20);
		this.add(L);
		
		M = new JTextField();
		M.setColumns(10);
		M.setBounds(313, 29, 86, 20);
		this.add(M);
		
		 rdbtnWriteThrough = new JRadioButton("Write Through");
		rdbtnWriteThrough.setBounds(109, 81, 109, 23);
		this.add(rdbtnWriteThrough);
		rdbtnWriteThrough.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				
					rdbtnWriteBack.setSelected(false);
					rdbtnWriteThrough.setSelected(true);
					policy=rdbtnWriteThrough.getText().trim();
				
			
				
			}
		});
		
		 rdbtnWriteBack = new JRadioButton("Write Back");
		rdbtnWriteBack.setBounds(249, 81, 109, 23);
		this.add(rdbtnWriteBack);
		rdbtnWriteBack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				
					rdbtnWriteThrough.setSelected(false);
					rdbtnWriteBack.setSelected(true);
					policy=rdbtnWriteBack.getText().trim();
				
			
				
			}
		});
		
		accessCycles = new JTextField();
		accessCycles.setBounds(121, 122, 86, 20);
		this.add(accessCycles);
		accessCycles.setColumns(10);
		
		JLabel lblWritingPolicy = new JLabel("Writing policy:");
		lblWritingPolicy.setBounds(10, 85, 90, 14);
		this.add(lblWritingPolicy);
		
		JLabel lblAccessCycles = new JLabel("Access cycles");
		lblAccessCycles.setBounds(10, 125, 90, 14);
		this.add(lblAccessCycles);
		
		JLabel lblS = new JLabel("S");
		lblS.setBounds(10, 32, 20, 14);
		this.add(lblS);
		
		JLabel lblL = new JLabel("L");
		lblL.setBounds(159, 32, 20, 14);
		this.add(lblL);
		
		JLabel lblM = new JLabel("M");
		lblM.setBounds(286, 32, 20, 14);
		this.add(lblM);
		

		
	}

	public static String getS() {
		return S.getText();
	}
	public static void setS(JTextField s) {
		S = s;
	}
	public static String getL() {
		return L.getText();
	}
	public static void setL(JTextField l) {
		L = l;
	}
	public static String getM() {
		return M.getText();
	}
	public static void setM(JTextField m) {
		M = m;
	}
	public static String getAccessCycles() {
		return accessCycles.getText();
	}
	public static void setAccessCycles(JTextField accessCycles) {
		CacheLayout.accessCycles = accessCycles;
	}
		
	}

	
