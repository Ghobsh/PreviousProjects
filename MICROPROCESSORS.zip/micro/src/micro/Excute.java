package micro;

import java.awt.EventQueue;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.DropMode;

public class Excute  {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 */
	public Excute() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		
		
		TextArea textField = new TextArea();
		textField.setBounds(10, 48, 240, 133);
		frame.getContentPane().add(textField);
		
		
				  
			
		
		JButton run = new JButton("Run");
		run.setBounds(290, 80, 89, 23);
		frame.getContentPane().add(run);
		
		run.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
			  //TODO replace array with instance array of instructions
		   String[] instructions= textField.getText().split(";");
		  }
		});
		
		
		JLabel lblEnterCode = new JLabel("Enter code. separate each line with ';'.");
		lblEnterCode.setBounds(22, 11, 228, 14);
		frame.getContentPane().add(lblEnterCode);
	}
}
